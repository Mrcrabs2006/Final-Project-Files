package com.example.smartchat.utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.model.UserModel;
import com.google.android.gms.tasks.Task;

import java.io.File;
import java.util.ArrayList;

public class AndroidUtil {
    private static final String TAG = "AndroidUtil";

    public static void showToastLong(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public static void showToastShort(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public static void passUserModelAsIntent(Intent intent, UserModel model) {
        intent.putExtra("username", model.getUsername());
        intent.putExtra("phone", model.getPhone());
        intent.putExtra("userId", model.getUserId());

    }

    public static void passGroupChatAsIntent(Intent intent, GroupChatModel model) {
        intent.putExtra("chatroomName", model.getChatroomName());
        intent.putExtra("chatroomId", model.getChatroomId());
        intent.putStringArrayListExtra("adminIds", new ArrayList<>(model.getAdminIds()));
        intent.putStringArrayListExtra("userIds", new ArrayList<>(model.getUserIds()));
    }

    public static GroupChatModel getGroupChatDetailsFromIntent(Intent intent) {
        GroupChatModel model = new GroupChatModel();
        model.setChatroomName(intent.getStringExtra("chatroomName"));
        model.setChatroomId(intent.getStringExtra("chatroomId"));
        model.setAdminIds(intent.getStringArrayListExtra("adminIds"));
        model.setUserIds(intent.getStringArrayListExtra("userIds"));
        return model;
    }


    public static UserModel getUserModelFromIntent(Intent intent) {
        UserModel userModel = new UserModel();
        userModel.setUsername(intent.getStringExtra("username"));
        userModel.setPhone(intent.getStringExtra("phone"));
        userModel.setUserId(intent.getStringExtra("userId"));

        return userModel;
    }

    // AndroidUtil.java


        public static void setProfilePic(Context context, Uri uri, ImageView imageView) {
            if (context instanceof Activity) {
                Activity activity = (Activity) context;
                if (activity.isDestroyed() || activity.isFinishing()) {
                    return; // Do not attempt to load the image if the activity is destroyed or finishing
                }
            }
            Glide.with(context).load(uri).apply(RequestOptions.circleCropTransform()).into(imageView);
        }


    public static String getFileExtension(Context context, Uri uri) {
        ContentResolver contentResolver = context.getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();

        // Get the file's content type
        String mimeType = contentResolver.getType(uri);

        // If the MIME type is null, try to get it from the file name
        if (mimeType == null) {
            String path = getPath(context, uri);
            if (path != null) {
                File file = new File(path);
                int lastDotIndex = file.getName().lastIndexOf('.');
                if (lastDotIndex > 0) {
                    return file.getName().substring(lastDotIndex + 1);
                }
            }
            return "";
        }

        // Get the extension from the MIME type
        return mimeTypeMap.getExtensionFromMimeType(mimeType);
    }

    private static String getPath(Context context, Uri uri) {
        String path = null;
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            if (cursor.moveToFirst()) {
                path = cursor.getString(column_index);
            }
            cursor.close();
        }
        return path;
    }


    public static Task<UserModel> getUserModel(String userId) {
        return FireBaseUtil.getUserDetails(userId).get().continueWith(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                return task.getResult().toObject(UserModel.class);
            } else {
                Log.e(TAG, "Error getting user details: ", task.getException());
                return null;
            }
        });
    }

}



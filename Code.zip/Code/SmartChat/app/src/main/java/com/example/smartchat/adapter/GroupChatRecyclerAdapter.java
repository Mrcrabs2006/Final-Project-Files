package com.example.smartchat.adapter;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.smartchat.R;
import com.example.smartchat.TranslationCallback;
import com.example.smartchat.model.ChatMessageModel;
import com.example.smartchat.model.GroupChatMessageModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.database.annotations.Nullable;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.io.OutputStream;

// GroupChatRecyclerAdapter.java

public class GroupChatRecyclerAdapter extends FirestoreRecyclerAdapter<GroupChatMessageModel, RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_TEXT = 1;
    private static final int VIEW_TYPE_IMAGE = 2;
    private static final int VIEW_TYPE_DOCUMENT = 3;

    private static final int VIEW_TYPE_CONTACT = 4;
    private static final String TAG = "GroupChatRecyclerAdapter";

    private Context context;
    private String selectedLanguage;
    private boolean translationEnabled;
    private Translator translator;
    private OnImageClickListener imageClickListener;
    UserModel senderUser;

    public GroupChatRecyclerAdapter(@NonNull FirestoreRecyclerOptions<GroupChatMessageModel> options, Context context, String selectedLanguage, boolean translationEnabled) {
        super(options);
        this.context = context;
        this.selectedLanguage = selectedLanguage;
        this.translationEnabled = translationEnabled;
    }

    @Override
    public int getItemViewType(int position) {
        GroupChatMessageModel model = getItem(position);
        String messageType = model.getMessageType();

        if (messageType == null) {
            return VIEW_TYPE_TEXT;
        }

        switch (messageType) {
            case "image":
                return VIEW_TYPE_IMAGE;
            case "document":
                return VIEW_TYPE_DOCUMENT;
            case "contact":
                return VIEW_TYPE_CONTACT;
            default:
                return VIEW_TYPE_TEXT;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_IMAGE) {
            View view = LayoutInflater.from(context).inflate(R.layout.group_chat_image_message_row, parent, false);
            return new ImageMessageViewHolder(view);
        } else if (viewType == VIEW_TYPE_DOCUMENT) {
            View view = LayoutInflater.from(context).inflate(R.layout.groupchat_document_message_row, parent, false);
            return new DocumentMessageViewHolder(view);
        } else if (viewType == VIEW_TYPE_CONTACT) {
            View view = LayoutInflater.from(context).inflate(R.layout.contact_group_message_row, parent, false);
            return new ContactMessageViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.group_chat_message_row, parent, false);
            return new TextMessageViewHolder(view);
        }
    }

    @Override
    protected void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, @NonNull GroupChatMessageModel model) {
        String currentUserId = FireBaseUtil.currentUSerId();

        switch (getItemViewType(position)) {
            case VIEW_TYPE_IMAGE:
                bindImageMessage((ImageMessageViewHolder) holder, model, currentUserId);
                break;
            case VIEW_TYPE_DOCUMENT:
                bindDocumentMessage((DocumentMessageViewHolder) holder, model, currentUserId);
                break;
            case VIEW_TYPE_CONTACT:
                bindContactMessage((ContactMessageViewHolder) holder, model, currentUserId);
                break;
            case VIEW_TYPE_TEXT:
            default:
                try {
                    bindTextMessage((TextMessageViewHolder) holder, model, currentUserId);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                break;
        }
    }




    private void bindImageMessage(ImageMessageViewHolder holder, GroupChatMessageModel model, String currentUserId) {
        String imageUrl = model.getMessage();
        boolean isCurrentUser = model.getSenderId().equals(currentUserId);

        if (isCurrentUser) {
            holder.rightImageLayout.setVisibility(View.VISIBLE);
            holder.leftImageLayout.setVisibility(View.GONE);
            Glide.with(holder.rightImageView.getContext())
                    .load(imageUrl)
                    .into(holder.rightImageView);
        } else {
            FireBaseUtil.getUserDetails(model.getSenderId()).get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    senderUser = task.getResult().toObject(UserModel.class);
                    holder.username.setText(senderUser.getUsername());
                }
            });

            holder.leftImageLayout.setVisibility(View.VISIBLE);
            holder.rightImageLayout.setVisibility(View.GONE);
            holder.imageTimeStamp.setText(FireBaseUtil.timestampToString(model.getTimestamp()));

            Glide.with(holder.leftImageView.getContext())
                    .load(imageUrl)
                    .into(holder.leftImageView);
        }

        View.OnClickListener imageClickListener = v -> {
            if (this.imageClickListener != null) {
                this.imageClickListener.onImageClick(imageUrl);
            }
        };

        holder.leftImageView.setOnClickListener(imageClickListener);
        holder.rightImageView.setOnClickListener(imageClickListener);
    }

    private void bindTextMessage(TextMessageViewHolder holder, GroupChatMessageModel model, String currentUserId) throws Exception {
        if (holder.leftChatTextview == null || holder.rightChatTextview == null || holder.leftChatLayout == null || holder.rightChatLayout == null) {
            Log.e(TAG, "ViewHolder views are not properly initialized");
            return;
        }

        if (model.getSenderId().equals(FireBaseUtil.currentUSerId())) {
            holder.leftChatLayout.setVisibility(View.GONE);
            holder.rightChatLayout.setVisibility(View.VISIBLE);
            holder.rightChatTextview.setText(model.getMessage());
        } else {
            FireBaseUtil.getUserDetails(model.getSenderId()).get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    senderUser = task.getResult().toObject(UserModel.class);
                    holder.username.setText(senderUser.getUsername());
                } else {
                    Log.e(TAG, "Error getting user details: ", task.getException());
                }
            });

            holder.rightChatLayout.setVisibility(View.GONE);
            holder.leftChatLayout.setVisibility(View.VISIBLE);
            holder.leftChatTextview.setText(model.getMessage());
            holder.messageTimeStamp.setText(FireBaseUtil.timestampToString(model.getTimestamp()));
        }
    }

    public void setTranslationEnabled(boolean enabled) {
        this.translationEnabled = enabled;
        notifyDataSetChanged();
    }

    public void setSelectedLanguage(String language) {
        this.selectedLanguage = language;
        notifyDataSetChanged();
    }

    public interface OnImageClickListener {
        void onImageClick(String imageUrl);
    }

    public void setOnImageClickListener(OnImageClickListener listener) {
        this.imageClickListener = listener;
    }

    static class TextMessageViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout leftChatLayout, rightChatLayout;
        TextView leftChatTextview, rightChatTextview, username, messageTimeStamp;

        public TextMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftChatLayout = itemView.findViewById(R.id.left_message_layout_g);
            rightChatLayout = itemView.findViewById(R.id.right_message_layout_g);
            leftChatTextview = itemView.findViewById(R.id.left_message_textview_g);
            username = itemView.findViewById(R.id.left_username_g);
            rightChatTextview = itemView.findViewById(R.id.right_message_textview_g);
            messageTimeStamp = itemView.findViewById(R.id.time_message_sent_g);
        }
    }

    static class ImageMessageViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout leftImageLayout, rightImageLayout;
        ImageView leftImageView, rightImageView;
        TextView username,imageTimeStamp;

        public ImageMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftImageLayout = itemView.findViewById(R.id.left_image_layout_g);
            username = itemView.findViewById(R.id.messageSender_name_g);
            rightImageLayout = itemView.findViewById(R.id.right_image_layout_g);
            imageTimeStamp = itemView.findViewById(R.id.message_time_g);
            leftImageView = itemView.findViewById(R.id.left_image_view_g);
            rightImageView = itemView.findViewById(R.id.right_image_view_g);
        }
    }

    static class DocumentMessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout leftDocumentLayout, rightDocumentLayout;
        TextView leftDocumentTextView, rightDocumentTextView,senderUserName;

        public DocumentMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftDocumentLayout = itemView.findViewById(R.id.left_document_layout_g);
            rightDocumentLayout = itemView.findViewById(R.id.right_document_layout_g);
            senderUserName = itemView.findViewById(R.id.text_username_g);
            leftDocumentTextView = itemView.findViewById(R.id.left_document_textview_g);
            rightDocumentTextView = itemView.findViewById(R.id.right_document_textview_g);
        }
    }

    private void bindDocumentMessage(GroupChatRecyclerAdapter.DocumentMessageViewHolder holder, GroupChatMessageModel model, String currentUserId) {

        if (model.getSenderId().equals(currentUserId)) {
            holder.leftDocumentLayout.setVisibility(View.GONE);
            holder.rightDocumentLayout.setVisibility(View.VISIBLE);
            holder.rightDocumentTextView.setText(model.getFileName());
        } else {
            holder.rightDocumentLayout.setVisibility(View.GONE);
            holder.leftDocumentLayout.setVisibility(View.VISIBLE);
            holder.leftDocumentTextView.setText(model.getFileName());
            holder.senderUserName.setText(model.getSenderUsername());
        }

        View.OnClickListener documentClickListener = v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(model.getMessage()), "*/*");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Add this line
            context.startActivity(intent);
        };

        holder.leftDocumentTextView.setOnClickListener(documentClickListener);
        holder.rightDocumentTextView.setOnClickListener(documentClickListener);
    }

    static class ContactMessageViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout leftContactLayout, rightContactLayout;
        TextView leftContactName, rightContactName, leftContactPhone, rightContactPhone, leftContactTime, rightContactTime,senderUser;

        public ContactMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftContactLayout = itemView.findViewById(R.id.left_contact_layout_g);
            rightContactLayout = itemView.findViewById(R.id.right_contact_layout_g);
            leftContactName = itemView.findViewById(R.id.left_contact_name_g);
            rightContactName = itemView.findViewById(R.id.right_contact_name_g);
            leftContactPhone = itemView.findViewById(R.id.contact_number_left_g);
            rightContactPhone = itemView.findViewById(R.id.contact_number_right_g);
            leftContactTime = itemView.findViewById(R.id.contact_time_left_g);
            rightContactTime = itemView.findViewById(R.id.contact_time_right_g);
            senderUser = itemView.findViewById(R.id.senderUserName_g);
        }
    }



    private void bindContactMessage(ContactMessageViewHolder holder, GroupChatMessageModel model, String currentUserId) {
        if (model.getSenderId().equals(currentUserId)) {
            holder.leftContactLayout.setVisibility(View.GONE);
            holder.rightContactLayout.setVisibility(View.VISIBLE);
            holder.rightContactName.setText(model.getContactName());
            holder.rightContactPhone.setText(model.getContactPhone());
            holder.rightContactTime.setText(FireBaseUtil.timestampToString(model.getTimestamp()));
        } else {
            holder.rightContactLayout.setVisibility(View.GONE);
            holder.leftContactLayout.setVisibility(View.VISIBLE);
            holder.leftContactName.setText(model.getContactName());
            holder.leftContactPhone.setText(model.getContactPhone());
            holder.leftContactTime.setText(FireBaseUtil.timestampToString(model.getTimestamp()));
            holder.senderUser.setText(model.getSenderUsername());
        }

        View.OnClickListener contactClickListener = v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + model.getContactPhone()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        };

        holder.leftContactLayout.setOnClickListener(contactClickListener);
        holder.rightContactLayout.setOnClickListener(contactClickListener);
    }
}
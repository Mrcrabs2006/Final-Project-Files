package com.example.smartchat.utils;

import com.example.smartchat.model.UserModel;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class FireBaseUtil {
    //return current user details if there is any!!;
    public static DocumentReference currentUserDetails() {
        return FirebaseFirestore.getInstance().collection("users").document(currentUSerId());
    }

    public static String currentUSerId() {
        return FirebaseAuth.getInstance().getUid();
    }

    public static boolean isLoggedIn() {
        return currentUSerId() != null;
    }

    public static CollectionReference allUsersCollectionReference() {
        return FirebaseFirestore.getInstance().collection("users");
    }

    public static DocumentReference getChatroomReference(String chatroomId) {
        return FirebaseFirestore.getInstance().collection("chatrooms").document(chatroomId);
    }
    public static DocumentReference getGroupChatReference(String groupChatId) {
        return FirebaseFirestore.getInstance().collection("GroupChats").document(groupChatId);
    }

    public static String getChatroomId(String userId1, String userId2) {
        if (userId1.hashCode() < userId2.hashCode()) {
            return userId1 + "_" + userId2;
        } else {
            return userId2 + "_" + userId1;
        }
    }

    public static CollectionReference getChatroomMessageReference(String chatroomId){
        return getChatroomReference(chatroomId).collection("chats");
    }

    public static CollectionReference allChatRoomCollectionReference(){
        return FirebaseFirestore.getInstance().collection("chatrooms");
    }

    public static DocumentReference getOtherUserFromChatroom(List<String> userIds){
        if(userIds.get(0).equals(FireBaseUtil.currentUSerId())){
            return allUsersCollectionReference().document(userIds.get(1));
        }else{
            return allUsersCollectionReference().document(userIds.get(0));
        }
    }

    public static String timestampToString(Timestamp timestamp) {
        if (timestamp == null) {
            return "";
        }
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(timestamp.toDate());
    }


    public static void logout() {
        FirebaseAuth.getInstance().signOut();
    }

    public static StorageReference getCurrentProfilePicStorageRef(){
        return FirebaseStorage.getInstance().getReference().child("profile_pic")
                .child(FireBaseUtil.currentUSerId());
    }

    public static StorageReference  getOtherProfilePicStorageRef(String otherUserId){
        return FirebaseStorage.getInstance().getReference().child("profile_pic")
                .child(otherUserId);
    }

    public static DocumentReference getUserDetails(String userId) {
        return FirebaseFirestore.getInstance().collection("users").document(userId);
    }

    public static CollectionReference getChatroomReference() {
        return FirebaseFirestore.getInstance().collection("chatrooms");
    }

    public static Query allGroupChatCollectionReference() {
        return FirebaseFirestore.getInstance().collection("GroupChats");
    }
    public static Query getGroupChatDetails(String GroupchatId) {
        return FirebaseFirestore.getInstance().collection("GroupChats").document(GroupchatId).getParent();
    }

    public static CollectionReference getGroupChatMessagesReference(String groupId) {
        return getGroupChatReference(groupId).collection("chats");
    }

    public static Task<String> getOneSignalExternalId(String firebaseUserId) {
        return getUserDetails(firebaseUserId).get().continueWith(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot documentSnapshot = task.getResult();
                if (documentSnapshot.exists() && documentSnapshot.contains("oneSignalExternalId")) {
                    return documentSnapshot.getString("oneSignalExternalId");
                }
            }
            return null; // Return null if the user doesn't have a OneSignalExternalId
        });
    }

    // FireBaseUtil.java
    public static Task<Boolean> isCurrentUserAdmin(String groupId) {
        return getGroupChatReference(groupId).get().continueWith(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot documentSnapshot = task.getResult();
                if (documentSnapshot.exists() && documentSnapshot.contains("adminIds")) {
                    List<String> adminIds = (List<String>) documentSnapshot.get("adminIds");
                    return adminIds != null && adminIds.contains(currentUSerId());
                }
            }
            return false;
        });
    }


    public static Task<String> currentUserName() {
        String currentUserId = currentUSerId();
        if (currentUserId == null) {
            return Tasks.forException(new Exception("User not logged in"));
        }

        DocumentReference userRef = FirebaseFirestore.getInstance().collection("users").document(currentUserId);
        return userRef.get().continueWith(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot documentSnapshot = task.getResult();
                if (documentSnapshot.exists() && documentSnapshot.contains("username")) {
                    return documentSnapshot.getString("username");
                }
            }
            throw new Exception("Failed to fetch username");
        });
    }
}

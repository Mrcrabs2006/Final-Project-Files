package com.example.smartchat;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.smartchat.databinding.ActivitySetUserNameBinding;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.FireBaseUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.onesignal.OneSignal;
import com.zegocloud.uikit.prebuilt.call.ZegoUIKitPrebuiltCallService;
import com.zegocloud.uikit.prebuilt.call.config.ZegoNotificationConfig;
import com.zegocloud.uikit.prebuilt.call.invite.ZegoUIKitPrebuiltCallInvitationConfig;
import com.zegocloud.uikit.service.defines.ZegoUIKitUser;

import java.util.UUID;

public class SetUserNameActivity extends AppCompatActivity {

    ActivitySetUserNameBinding binding;
    String phoneNumber;
    UserModel userModel;
    String defaultStatus= "Hey there Iam using SmartChat";
    private boolean isCallServiceInitialized = false;
    private static final int OVERLAY_PERMISSION_REQ_CODE = 1234;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySetUserNameBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        checkSystemAlertWindowPermission();

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        phoneNumber = getIntent().getStringExtra("phoneNumber");
        fetchAndDisplayUserName();

        binding.createAcountBtn.setOnClickListener((v -> {
            String username = binding.usernameEdittxt.getText().toString();
            if (username.isEmpty() || username.length() < 3) {
                binding.usernameEdittxt.setError("Username is required");
                return;
            } else {
                setUserName();
            }
        }));
    }

    private void setUserName() {
        String userName = binding.usernameEdittxt.getText().toString();
        if (userModel != null) {
            userModel.setUsername(userName);
        } else {
            userModel = new UserModel(phoneNumber, userName, Timestamp.now(), FireBaseUtil.currentUSerId());
        }

        FireBaseUtil.currentUserDetails().set(userModel).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // Generate and set OneSignal external ID
                    String externalId = UUID.randomUUID().toString();
                    OneSignal.login(externalId);


                    FireBaseUtil.currentUserDetails().update("status",defaultStatus);



                    // Update Fiirestore with the external ID
                    FireBaseUtil.currentUserDetails().update("oneSignalExternalId", externalId)
                            .addOnSuccessListener(aVoid -> {
                                Log.d("Firestore", "External ID updated successfully.");
                                Intent intent = new Intent(SetUserNameActivity.this, MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            })
                            .addOnFailureListener(e -> {
                                Log.e("Firestore", "Failed to update external ID in Firestore", e);
                                // Handle failure (e.g., show an error message or retry)
                            });
                } else {
                    // Handle failure to set username (e.g., show an error message or retry)
                    Log.e("SetUserName", "Failed to set username", task.getException());
                }
            }
        });
    }

    private void checkSystemAlertWindowPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE);
        } else {
            initializeCallService();
        }
    }


    private void fetchAndDisplayUserName() {
        FireBaseUtil.currentUserDetails().get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                UserModel userModel = task.getResult().toObject(UserModel.class);
                if (userModel != null) {
                    binding.createAcountBtn.setText(R.string.login); // Use string resources for UI text
                    binding.usernameEdittxt.setText(userModel.getUsername());
                }
            } else {
                // Handle the case where the task is unsuccessful, e.g., log the error
                Log.e("FetchUserName", "Error fetching user details", task.getException());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isCallServiceInitialized) {
            ZegoUIKitPrebuiltCallService.unInit();
            isCallServiceInitialized = false;
        }
    }

    private void initializeCallService() {
        if (isCallServiceInitialized) {
            Log.d(TAG, "Call service already initialized");
            return;
        }

        long appID = getResources().getInteger(R.integer.app_id);
        String appSign = getString(R.string.app_sign);
        String currentUserId = FireBaseUtil.currentUSerId();

        FireBaseUtil.getUserDetails(currentUserId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                UserModel user = task.getResult().toObject(UserModel.class);
                if (user != null) {
                    ZegoUIKitPrebuiltCallInvitationConfig callInvitationConfig = new ZegoUIKitPrebuiltCallInvitationConfig();

                    ZegoNotificationConfig notificationConfig = new ZegoNotificationConfig();
                    notificationConfig.sound = "zego_uikit_sound_call";
                    notificationConfig.channelID = "CallInvitation";
                    notificationConfig.channelName = "CallInvitation";
                    callInvitationConfig.notificationConfig = notificationConfig;

                    ZegoUIKitUser currentUser = new ZegoUIKitUser(user.getUserId(), user.getUsername());

                    ZegoUIKitPrebuiltCallService.init(
                            getApplication(),
                            appID,
                            appSign,
                            currentUser.userID,
                            currentUser.userName,
                            callInvitationConfig
                    );
                    isCallServiceInitialized = true;
                    Log.d(TAG, "Call service initialized successfully");
                } else {
                    Log.e(TAG, "Failed to initialize call service: User is null");
                }
            } else {
                Log.e(TAG, "Failed to initialize call service: " + task.getException().getMessage());
            }
        });
    }
}

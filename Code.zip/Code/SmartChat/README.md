1	INTRODUCTION
Greetings from the Smart Chat developers! With the help of this user manual, you can connect, communicate, and work with friends, family, and coworkers more quickly and securely thanks to the Smart Chat app's features and functionalities. Smart Chat offers an easy and safe messaging solution that keeps you connected, whether you want to remain in touch, create group chats, or exchange vital updates.

2	GETTING STARTED

2.1	SIGNING UP:
All you need to sign up for Smart Chat is your phone number. You are required to enter your phone number into the app to get a verification code that is delivered to your phone via SMS. You'll be prompted to create a username after your number has been validated. After setting your username, you're ready to start using Smart Chat and connect with your contacts. It's that simple—no extra details needed!


2.2	LOGGING IN:
The log in process in Smart Chat is just as simple as signing up. Enter your phone number, and once verified, your previous username will automatically appear. You can choose to keep your existing username or edit it to something new before logging in. This flexibility makes getting back into Smart Chat quick and effortless.


3	STARTING A CHATROOM

3.1	ONE TO ONE:
Go to the main app interface of Smart Chat and select the search icon to start a one-to-one conversation. From there, you have two options: click on the contacts button to show app users from your list of contacts, or search for the user by entering their username or phone number. Once you've located the person you want to message, all you have to do is click on their profile to open a chat window and start conversing.

3.2	GROUP CHAT:
In Smart Chat, click "More Options" from the main menu and choose "Create Group Chat" to start a group chat. You can choose which contacts you wish to add to the group by selecting them from the list that displays. Once you've chosen your participants, give your group chat a name, and then click "Create" to create it.



4	FEATURES

4.1	TRANSLATION:
To use the translation feature in Smart Chat, enter the chatroom where you want to enable translation. Click on the translation button located on the toolbar, toggle the feature on, and choose your preferred language. Once activated, the required language model will be downloaded, and incoming messages will be automatically translated into the selected language. You can change the language anytime by revisiting the translation settings.

4.2	AI PROMPTING:
To utilize the AI feature in Smart Chat, simply type /prompt in the message input field followed by your query. The AI will process your request, and the generated response will be displayed in the message input area. You can then opt to send the answer or remove it.

4.3	SPEECH TO TEXT:
Click the microphone icon in the toolbar and recite your message to utilize Smart Chat's speech-to-text capability. When you're finished, the text you've transcribed will show up in the message input form and will be ready to be sent.



4.4	ONE-TO-ONE CALL:
To use the one-to-one call feature in Smart Chat, enter a one-to-one chatroom and click the call icon. You’ll be prompted to choose either a voice call or a video call. Once you make your selection, the call will start immediately.

4.5	GROUP CALL:
For the group call feature in Smart Chat, enter a group chat and click the call icon. You’ll be given the option to start either a voice call or a video call with the group. After selecting your preferred call type, the group call will begin, allowing all members to join in or decline.

4.6	SENDING A PICTURE:
For the picture-sending feature in Smart Chat, click the attachment button in the chatroom and choose either the camera or gallery as the source. Once you've selected or captured a picture, you'll have the option to edit its dimensions. After making the adjustments, click the checkmark, and the image will be sent to the chatroom you've chosen.

4.7	SENDING A DOCUMENT:
To send a document, navigate to the toolbar and click on 'More Options'. From the dropdown menu, select 'Send a Document'. This will prompt you to choose a file from your device's storage. Browse through your files and select the document you wish to send. Once selected, the document will be sent successfully. This feature allows you to easily share documents with others directly from the app.

4.8	SENDING A CONTACT:
To share a contact, access the toolbar and click on 'Send Contact'. This will open your device's contact list. Browse through your contacts and select the one you wish to share. Once selected, the contact information will be sent successfully. This feature enables you to quickly share contact details with others directly from the app.

4.9	BLOCKING A USER:
To block a user in a one-on-one chatroom, go to the toolbar and choose 'More Options'. From the dropdown option, choose 'Block'. This prevents the individual from contacting you and sending you messages. Once blocked, the user will be unable to begin chats with you, resulting in a more secure and controlled chatting experience.


4.10	GROUP ADMIN RIGHTS:
You possess special rights as a group admin, which lets you run the group efficiently. You can add new members, remove existing ones from the group, and even change the group name using these capabilities. 

5	PROFILE:

5.1	SETTING/CHANGING A PROFILE IMAGE:
To set or change your profile image, follow these steps. Click on your current profile picture, then choose the source of the new image: either take a new photo using your camera or select an existing one from your gallery. Select the desired image and click the checkmark to confirm and save the changes. By following these steps, you can easily update your profile image and showcase your new look within the app.

5.2	CHANGING USERNAME/STATUS:
To make changes to your username or status, simply click on the input field that corresponds to the desired change in information. After entering the new data you wish to see, click "Update Profile" to save the modifications to the database. You may quickly update your username and status by following these steps.

6	SETTINGS

6.1	APP LANGUAGE:
To change the language of the app's user interface, simply select your preferred language from the options provided, which include Spanish, Arabic, English, and French. Once you've made your selection, the app's language will be updated and saved, allowing you to navigate the app in your chosen language.





6.2	ANIMATIONS:
You can customize your app experience by turning icon animations on or off. This feature allows you to personalize the visual effects of the app to your liking and allows saving battery and resources.

6.3	LOGOUT:
If you need to log out of your account, you can do so easily by clicking on the "Logout" option. This will securely sign you out of your account, and you will need to log back in to access the app's features again.

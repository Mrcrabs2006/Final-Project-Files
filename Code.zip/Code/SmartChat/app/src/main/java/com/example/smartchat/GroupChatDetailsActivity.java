package com.example.smartchat;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.smartchat.adapter.UsersAdapterGroup;
import com.example.smartchat.databinding.ActivityGroupChatDetailsBinding;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.Query;
import java.util.List;
import java.util.Objects;

public class GroupChatDetailsActivity extends AppCompatActivity {

    ActivityGroupChatDetailsBinding binding;
    private RecyclerView recyclerView;
    private UsersAdapterGroup adapter;
    private String groupId;
    private String groupName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGroupChatDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        groupId = getIntent().getStringExtra("groupId");
        groupName = getIntent().getStringExtra("groupName");

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.group_chat_details_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.groupName.setText(groupName);

        // Fetch user IDs and setup RecyclerView
        fetchUserIdsAndSetupRecyclerView();
        binding.backBtn.setOnClickListener(v->{
            getOnBackPressedDispatcher().onBackPressed();
        });
    }

    private void fetchUserIdsAndSetupRecyclerView() {
        FireBaseUtil.getGroupChatReference(groupId).addSnapshotListener((snapshot, e) -> {
            if (e != null) {
                // Handle error
                return;
            }
            if (snapshot != null && snapshot.exists()) {
                List<String> userIds = Objects.requireNonNull(snapshot.toObject(GroupChatModel.class)).getUserIds();
                userIds.remove(FireBaseUtil.currentUSerId());
                setupRecyclerView(userIds);
            }
        });
    }


    private void setupRecyclerView(List<String> userIds) {
        Query query = FireBaseUtil.allUsersCollectionReference().whereIn("userId", userIds);
        FirestoreRecyclerOptions<UserModel> options = new FirestoreRecyclerOptions.Builder<UserModel>()
                .setQuery(query, UserModel.class)
                .build();

        adapter = new UsersAdapterGroup(options, this, groupId);
        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adapter != null) {
            adapter.startListening();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }
    }
}
package com.example.smartchat;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OneSignalManager {

    private static final String APP_ID = "649098a9-16cd-4c60-b5fa-6aaef0b0422d";
    private static final String REST_API_KEY = "ZGY3MTkwNTEtNDQwMy00Y2M1LThlNGUtZDI5MzQ0MmM4OTZh";
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    public static void sendNotification(String title, String message, String externalId) {
        executor.execute(() -> {
            OkHttpClient client = new OkHttpClient();

            MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
            String json = "{\n" +
                    "  \"app_id\": \"" + APP_ID + "\",\n" +
                    "  \"contents\": {\"en\": \"" + message + "\"},\n" +
                    "  \"headings\": {\"en\": \"" + title + "\"},\n" +
                    "  \"target_channel\": \"push\",\n" +
                    "  \"include_external_user_ids\": [\n" +
                    "    \"" + externalId + "\"\n" +
                    "  ]\n" +
                    "}";

            RequestBody body = RequestBody.create(mediaType, json);
            Request request = new Request.Builder()
                    .url("https://onesignal.com/api/v1/notifications")
                    .post(body)
                    .addHeader("Content-Type", "application/json; charset=utf-8")
                    .addHeader("Authorization", "Basic " + REST_API_KEY)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    System.out.println("Notification sent successfully: " + response.body().string());
                } else {
                    System.err.println("Error sending notification: " + response.body().string());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void main(String[] args) {
        sendNotification("Test Title", "Test message", "CUSTOM-EXTERNAL_ID-ASSIGNED-BY-YOU");
    }
}

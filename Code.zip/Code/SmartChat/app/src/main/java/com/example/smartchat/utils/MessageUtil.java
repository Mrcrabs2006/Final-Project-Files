// File: app/src/main/java/com/example/smartchat/utils/MessageUtil.java
package com.example.smartchat.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;

import com.example.smartchat.model.ChatMessageModel;
import com.example.smartchat.model.GroupChatMessageModel;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;

public class MessageUtil {

    @SuppressLint("Range")
    public static void sendContactMessage(Context context, Uri contactUri, String chatRoomId, boolean isGroupChat) {
        String contactName = null;
        String contactPhone = null;

        Cursor cursor = context.getContentResolver().query(contactUri, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
            Cursor phones = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);
            if (phones != null && phones.moveToFirst()) {
                contactPhone = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                phones.close();
            }
            cursor.close();
        }

        if (contactName != null && contactPhone != null) {



            if (isGroupChat) {
                GroupChatMessageModel groupChatMessageModel = new GroupChatMessageModel(contactName, contactPhone, FireBaseUtil.currentUSerId(), Timestamp.now(), "tester");
                groupChatMessageModel.setMessageType("contact");
                Log.i("TAG", "sendContactMessage: "+chatRoomId);
                FireBaseUtil.getGroupChatMessagesReference(chatRoomId).add(groupChatMessageModel);
            } else {
                ChatMessageModel chatMessageModel = new ChatMessageModel(contactName, contactPhone, FireBaseUtil.currentUSerId(), Timestamp.now());
                chatMessageModel.setMessageType("contact");
                FireBaseUtil.getChatroomMessageReference(chatRoomId).add(chatMessageModel);
            }
        }
    }
}
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.gms.google.services)
    alias(libs.plugins.jetbrains.kotlin.android)
}



android {
    namespace = "com.example.smartchat"
    compileSdk = 34




    packaging {

        resources.excludes.add("META-INF/DEPENDENCIES")
        resources.excludes.add("google/protobuf/type.proto")

    }



    buildFeatures {
        viewBinding = true
    }

    viewBinding {
        enable = true
    }

    defaultConfig {
        applicationId = "com.example.smartchat"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        resValue("integer", "app_id", "23887433")
        resValue(
            "string",
            "app_sign",
            "e45cf176261589a674e19b00d5c6ae7367184e0e187c445fbacfe12fd10016b1"
        )

    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "17"
    }


}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation(libs.firebase.firestore)
    implementation(libs.navigation.fragment)
    implementation(libs.preference)
    implementation(libs.navigation.ui)
    implementation(libs.firebase.storage)
    implementation(libs.firebase.messaging)
    implementation(libs.volley)
    implementation(libs.core.ktx)
    implementation(libs.recyclerview)
    implementation(libs.lifecycle.livedata.ktx)
    implementation(libs.lifecycle.viewmodel.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    implementation("com.hbb20:ccp:2.7.3")
    implementation(libs.lottie.v641)
    implementation(libs.lottie.compose)

    // Import the BoM for the Firebase platform
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))

    // Add the dependency for the Firebase Authentication library
    // When using the BoM, you don't specify versions in Firebase library dependencies
    implementation("com.google.firebase:firebase-auth")

    implementation("com.makeramen:roundedimageview:2.3.0")

    implementation("com.intuit.sdp:sdp-android:1.1.1")

    implementation("com.intuit.ssp:ssp-android:1.1.1")


    // FirebaseUI for Firebase Realtime Database
    implementation("com.firebaseui:firebase-ui-database:8.0.2")

    // FirebaseUI for Cloud Firestore
    implementation("com.firebaseui:firebase-ui-firestore:8.0.2")

    // FirebaseUI for Firebase Auth
    implementation("com.firebaseui:firebase-ui-auth:8.0.2")

    // FirebaseUI for Cloud Storage
    implementation("com.firebaseui:firebase-ui-storage:8.0.2")

    implementation(libs.imagepicker)

    implementation("androidx.activity:activity-ktx:1.9.1")

    implementation(libs.google.auth.library.oauth2.http)

    implementation("androidx.fragment:fragment-ktx:1.8.2")

    implementation("com.squareup.okhttp3:okhttp:4.9.1")

    implementation("com.onesignal:OneSignal:5.1.20")

    implementation("com.google.code.gson:gson:2.8.6")





    implementation("com.google.mlkit:translate:17.0.3")

    implementation("com.google.mlkit:language-id:17.0.6")
    // ...
    // Use this dependency to use the dynamically downloaded model in Google Play Services
    implementation("com.google.android.gms:play-services-mlkit-language-id:17.0.0")

    // add the dependency for the Google AI client SDK for Android
    implementation("com.google.ai.client.generativeai:generativeai:0.7.0")

    // Required for one-shot operations (to use `ListenableFuture` from Guava Android)
    implementation("com.google.guava:guava:31.0.1-android")

    // Required for streaming operations (to use `Publisher` from Reactive Streams)
    implementation("org.reactivestreams:reactive-streams:1.0.4")


    implementation("com.github.ZEGOCLOUD:zego_uikit_prebuilt_call_android:+")
    implementation("com.github.ZEGOCLOUD:zego_uikit_signaling_plugin_android:+")// add this line in your module-level build.gradle file's dependencies, usually named [app].
    implementation("com.github.chrisbanes:PhotoView:2.3.0")

    annotationProcessor("com.github.bumptech.glide:compiler:4.12.0")

    // build.gradle (Module: app)














    implementation(libs.glide)


}
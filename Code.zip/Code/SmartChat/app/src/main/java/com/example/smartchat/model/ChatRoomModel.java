package com.example.smartchat.model;

import com.google.firebase.Timestamp;

import java.util.ArrayList;
import java.util.List;

public class ChatRoomModel {
    String chatroomId;
    List<String> userIds;
    Timestamp lastMessageTimestamp;
    String lastMessageSenderId;
    String lastMessage;

    public ChatRoomModel() {
        // Initialize with default values
        this.chatroomId = "";
        this.userIds = new ArrayList<>();
        this.lastMessageTimestamp = Timestamp.now();
        this.lastMessageSenderId = "";
        this.lastMessage = "";
    }

    public ChatRoomModel(String chatroomId, List<String> userIds, Timestamp lastMessageTimestamp, String lastMessageSenderId) {
        this.chatroomId = chatroomId != null ? chatroomId : "";
        this.userIds = userIds != null ? userIds : new ArrayList<>();
        this.lastMessageTimestamp = lastMessageTimestamp != null ? lastMessageTimestamp : Timestamp.now();
        this.lastMessageSenderId = lastMessageSenderId != null ? lastMessageSenderId : "";
        this.lastMessage = "";
    }

    // Getters and setters remain the same, but we'll add null checks

    public String getChatroomId() {
        return chatroomId != null ? chatroomId : "";
    }

    public List<String> getUserIds() {
        return userIds != null ? userIds : new ArrayList<>();
    }

    public Timestamp getLastMessageTimestamp() {
        return lastMessageTimestamp != null ? lastMessageTimestamp : Timestamp.now();
    }

    public String getLastMessageSenderId() {
        return lastMessageSenderId != null ? lastMessageSenderId : "";
    }

    public String getLastMessage() {
        return lastMessage != null ? lastMessage : "";
    }
    public void setLastMessageTimestamp(Timestamp lastMessageTimestamp) {
        this.lastMessageTimestamp = lastMessageTimestamp;
    }


    public void setLastMessageSenderId(String lastMessageSenderId) {
        this.lastMessageSenderId = lastMessageSenderId;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }
}
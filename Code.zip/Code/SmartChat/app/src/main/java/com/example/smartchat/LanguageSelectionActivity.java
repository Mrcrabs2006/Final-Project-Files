package com.example.smartchat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.smartchat.databinding.ActivityLanguageSelectionBinding;

import java.util.Locale;

public class LanguageSelectionActivity extends AppCompatActivity {
    ActivityLanguageSelectionBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLanguageSelectionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AnimationUtils.controlLottieAnimation(this,binding.lotteAnimation);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        binding.englishButton.setOnClickListener(v -> setLocale("en"));
//        binding.spanishButton.setOnClickListener(v -> setLocale("es"));
//        binding.btnArabic.setOnClickListener(v->setLocale("ar"));



        binding.btnSetLang.setOnClickListener(v -> {
            String lang = binding.spinnerLang.getSelectedItem().toString();


            switch (lang){
                case "Arabic":
                    setLocale("ar");
                    break;
                case "English":
                    setLocale("en");
                    break;
                case "French":
                    setLocale("fr");
                    break;
                case "Spanish":
                    setLocale("es");
                    break;

            }
        });






    }


    private void setLocale(String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();

        // Restart activity to apply language change
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
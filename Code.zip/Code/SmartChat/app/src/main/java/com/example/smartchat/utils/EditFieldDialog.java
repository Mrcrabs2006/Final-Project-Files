package com.example.smartchat.utils;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.smartchat.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;

public class EditFieldDialog extends BottomSheetDialogFragment {

    private EditText editText;
    private MaterialButton checkmarkBtn;
    private String initialText;
    private OnFieldEditedListener listener;

    public EditFieldDialog(String initialText, OnFieldEditedListener listener) {
        this.initialText = initialText;
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_edit_field, container, false);

        editText = view.findViewById(R.id.editText);
        checkmarkBtn = view.findViewById(R.id.checkmark_btn);

        editText.setText(initialText);

        checkmarkBtn.setOnClickListener(v -> {
            String newText = editText.getText().toString();
            listener.onFieldEdited(newText);
            dismiss();
        });

        return view;
    }

    public interface OnFieldEditedListener {
        void onFieldEdited(String newText);
    }
}
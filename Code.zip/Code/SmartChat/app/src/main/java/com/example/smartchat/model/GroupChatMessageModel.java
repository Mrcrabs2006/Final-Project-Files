package com.example.smartchat.model;

import com.google.firebase.Timestamp;

public class GroupChatMessageModel {
    private String message;
    private String senderId;
    private String senderUsername;
    private Timestamp timestamp;
    private String messageType;
    String fileName;
    String fileExtension;
    String contactName, contactPhone;

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getFileExtension() {
        return fileExtension;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public GroupChatMessageModel() {
    }

    public GroupChatMessageModel(String message, String senderId, String senderUsername, Timestamp timestamp) {
        this.message = message;
        this.senderId = senderId;
        this.senderUsername = senderUsername;
        this.timestamp = timestamp;
    }

    public GroupChatMessageModel(String contactName, String contactPhone, String senderId, Timestamp timestamp, String senderUsername) {
        this.contactName = contactName;
        this.senderId = senderId;
        this.contactPhone = contactPhone;
        this.senderId = senderId;
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderUsername() {
        return senderUsername;
    }

    public void setSenderUsername(String senderUsername) {
        this.senderUsername = senderUsername;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }
}

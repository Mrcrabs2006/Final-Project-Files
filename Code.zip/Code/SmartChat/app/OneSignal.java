import android.app.Application;

public class OneSignal extends Application {
    OneSignal.

}

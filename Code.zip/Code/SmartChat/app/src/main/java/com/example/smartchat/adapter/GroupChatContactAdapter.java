package com.example.smartchat.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.R;
import com.example.smartchat.model.UserModel;

import java.util.ArrayList;
import java.util.List;

public class GroupChatContactAdapter extends RecyclerView.Adapter<GroupChatContactAdapter.ViewHolder> {

    private final List<UserModel> userList;
    private final Context context;
    private final List<String> selectedUserIds;

    public GroupChatContactAdapter(List<UserModel> userList, Context context) {
        this.userList = userList;
        this.context = context;
        this.selectedUserIds = new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.group_chat_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (userList.isEmpty() || position >= userList.size()) {
            return;
        }
        UserModel user = userList.get(position);


        holder.lastMessage.setText(user.getPhone());
        // Load user image if available
        holder.userImage.setImageResource(R.drawable.profile_round); // Placeholder image

        holder.selectUser.setOnCheckedChangeListener(null);
        holder.selectUser.setChecked(selectedUserIds.contains(user.getUserId()));
        if (user.getUsername()==null){
            holder.userName.setText(user.getPhone());
        }else {
            holder.userName.setText(user.getUsername());
        }
        holder.selectUser.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selectedUserIds.add(user.getUserId());
            } else {
                selectedUserIds.remove(user.getUserId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public List<String> getSelectedUserIds() {
        return selectedUserIds;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView userName, lastMessage;
        ImageView userImage;
        CheckBox selectUser;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.userName_txt_checkbox);
            lastMessage = itemView.findViewById(R.id.lastMessage_txt);
            userImage = itemView.findViewById(R.id.img_user);
            selectUser = itemView.findViewById(R.id.selectUser);
        }
    }


}
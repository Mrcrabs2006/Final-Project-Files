package com.example.smartchat;


import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.smartchat.adapter.GroupChatRecyclerAdapter;
import com.example.smartchat.databinding.ActivityGroupChatTextingBinding;
import com.example.smartchat.model.GroupChatMessageModel;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.example.smartchat.utils.MessageUtil;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.github.chrisbanes.photoview.PhotoView;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.zegocloud.uikit.plugin.invitation.ZegoInvitationType;
import com.zegocloud.uikit.prebuilt.call.invite.ZegoUIKitPrebuiltCallInvitationConfig;
import com.zegocloud.uikit.prebuilt.call.invite.widget.ZegoSendCallInvitationButton;
import com.zegocloud.uikit.service.defines.ZegoUIKitUser;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class GroupChatTexting extends AppCompatActivity {

    ActivityGroupChatTextingBinding binding;
    GroupChatModel groupChatModel;
    GroupChatRecyclerAdapter adapter;
    RecyclerView recyclerView;
    String groupId;
    UserModel userModel;
    UserModel userModelForImage;
    private SharedPreferences preferences;
    private static final int PICK_DOCUMENT_REQUEST = 1;
    private static final int PICK_CONTACT_REQUEST = 2;
    private String currentImageUrl;

    private static final int STORAGE_PERMISSION_CODE = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityGroupChatTextingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        preferences = getSharedPreferences("ChatPrefs", Context.MODE_PRIVATE);

        groupChatModel = AndroidUtil.getGroupChatDetailsFromIntent(getIntent());
        groupId = groupChatModel.getChatroomId();
        binding.toolbar.groupNameTxt.setText(groupChatModel.getChatroomName());
        boolean isAdmin = groupChatModel.getAdminIds().contains(FireBaseUtil.currentUSerId());

        binding.toolbar.groupNameTxt.setOnClickListener(v -> {
            Intent intent = new Intent(GroupChatTexting.this, GroupChatDetailsActivity.class);
            startActivity(intent);
        });

        recyclerView = binding.groupChatRecyclerViewMessage;
        setupRecyclerView();


        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_groubChat), (v, insets) -> {
            // Get system bars insets
            Insets systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Apply padding only to left, top, and right
            v.setPadding(systemBarsInsets.left, systemBarsInsets.top, systemBarsInsets.right, insets.getSystemWindowInsetBottom());

            // Return the insets to indicate they have been consumed
            return WindowInsetsCompat.CONSUMED;
        });

        OnBackPressedDispatcher onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                navigateToMainActivity();
            }
        });

        binding.toolbar.backBtn.setOnClickListener(v -> {
            navigateToMainActivity();
        });

        binding.toolbar.moreOptions.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(GroupChatTexting.this, v);
            popupMenu.getMenuInflater().inflate(R.menu.group_chat_options_menu, popupMenu.getMenu());
            popupMenu.getMenu().findItem(R.id.add_members).setVisible(isAdmin);

            popupMenu.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.leaveGroup) {
                    leaveGroup();
                    return true;
                } else if (item.getItemId() == R.id.add_members) {
                    addMembers();
                    return true;
                } else if (item.getItemId() == R.id.sendDocument_g) {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("*/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(intent, "Select Document"), PICK_DOCUMENT_REQUEST);
                    return true;
                } else if (item.getItemId() == R.id.sendContact_g) {
                    Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                    startActivityForResult(intent, PICK_CONTACT_REQUEST);
                    return true;
                }
                return false;
            });

            popupMenu.show();
        });

        binding.messageSendBtn.setOnClickListener(v -> {
            String message = binding.chatMessageInput.getText().toString().trim();
            if (message.isEmpty()) {
                return;
            }
            sendMessageToGroup(message);

        });

        binding.attachImage.setOnClickListener(v -> {
            // Implement image picker for group chat if needed
        });

        binding.toolbar.callBtn.setOnClickListener(v -> {
            showCallOptionsDialog();
        });
        binding.attachImage.setOnClickListener(v -> {
            openMediaPicker();
            ;
        });


        binding.toolbar.groupNameTxt.setOnClickListener(v -> {
            Intent intent = new Intent(GroupChatTexting.this, GroupChatDetailsActivity.class);
            intent.putExtra("groupId", groupId);
            intent.putExtra("groupName", groupChatModel.getChatroomName());
            startActivity(intent);
        });


    }

    // GroupChatTexting.java
    private void openMediaPicker() {
        ImagePicker.with(GroupChatTexting.this)
                .cropSquare()
                .compress(512)
                .maxResultSize(512, 512)
                .createIntent(intent -> {
                    imagePickLauncher.launch(intent);
                    return null;
                });
    }

    private void scrollToBottom() {
        recyclerView.post(() -> recyclerView.scrollToPosition(adapter.getItemCount() - 1));
    }

    private final ActivityResultLauncher<Intent> imagePickLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null && data.getData() != null) {
                        Uri selectedImageUri = data.getData();
                        if (selectedImageUri != null) {
                            sendImageMessage(selectedImageUri);
                        } else {
                            AndroidUtil.showToastShort(GroupChatTexting.this, "Error");
                        }
                    }
                }
            }
    );

    private void sendImageMessage(Uri imageUri) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child("Image Files")
                .child(groupId)
                .child(System.currentTimeMillis() + "." + AndroidUtil.getFileExtension(this, imageUri));

        storageReference.putFile(imageUri).addOnSuccessListener(taskSnapshot -> {
            storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                String imageUrl = uri.toString();
                sendImageMessageToGroup(imageUrl);
            });
        }).addOnFailureListener(e -> {
            AndroidUtil.showToastShort(GroupChatTexting.this, "Failed to upload image");
        });
    }

    private void sendImageMessageToGroup(String imageUrl) {
        final String[] senderUser = new String[1];


        FireBaseUtil.currentUserDetails().get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                userModelForImage = task.getResult().toObject(UserModel.class);


                if (userModel != null) {
                    assert userModelForImage != null;
                    senderUser[0] = userModelForImage.getUsername();

                }
            }
        });


        groupChatModel.setLastMessageTimestamp(Timestamp.now());
        groupChatModel.setLastMessageSenderId(FireBaseUtil.currentUSerId());
        groupChatModel.setLastMessage("Image");
        FireBaseUtil.getGroupChatReference(groupId).set(groupChatModel);

        GroupChatMessageModel chatMessageModel = new GroupChatMessageModel(imageUrl, FireBaseUtil.currentUSerId(), senderUser[0], Timestamp.now());
        chatMessageModel.setMessageType("image");
        FireBaseUtil.getGroupChatMessagesReference(groupId).add(chatMessageModel)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        AndroidUtil.showToastShort(GroupChatTexting.this, "Image sent successfully");
                    }
                });
    }

    private void showCallOptionsDialog() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(GroupChatTexting.this);
        View view = LayoutInflater.from(GroupChatTexting.this).inflate(R.layout.user_bottom_sheet, null);
        bottomSheetDialog.setContentView(view);
        bottomSheetDialog.show();

        ZegoUIKitPrebuiltCallInvitationConfig callInvitationConfig
                = new ZegoUIKitPrebuiltCallInvitationConfig();


        TextView userNameTV = view.findViewById(R.id.userNameTV);
        TextView userIdTV = view.findViewById(R.id.userIdTV);

        ZegoSendCallInvitationButton voiceCallBtn = view.findViewById(R.id.voiceCallBtn);
        ZegoSendCallInvitationButton videoCallBtn = view.findViewById(R.id.videoCallBtn);

        List<ZegoUIKitUser> invitees = new ArrayList<>();
        for (String userId : groupChatModel.getUserIds()) {
            if (!userId.equals(FireBaseUtil.currentUSerId())) {
                FireBaseUtil.getUserDetails(userId).get().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        UserModel userModel = task.getResult().toObject(UserModel.class);
                        if (userModel != null) {
                            invitees.add(new ZegoUIKitUser(userModel.getUserId(), userModel.getUsername()));
                        }
                    }
                });
            }
        }

        voiceCallBtn.setIsVideoCall(false);
        voiceCallBtn.setType(ZegoInvitationType.VOICE_CALL);
        voiceCallBtn.setResourceID("call");
        voiceCallBtn.setInvitees(invitees);

        videoCallBtn.setIsVideoCall(true);
        videoCallBtn.setType(ZegoInvitationType.VIDEO_CALL);
        videoCallBtn.setResourceID("call");


        videoCallBtn.setInvitees(invitees);


        userNameTV.setText(groupChatModel.getChatroomName());
        userIdTV.setText(String.format("%s", "Initiate a call with all group members"));
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(GroupChatTexting.this, MainActivity.class);
        intent.putExtra("navigateToGroupChat", true);
        startActivity(intent);
        finish();
    }

    private void addMembers() {
        Intent intent = new Intent(GroupChatTexting.this, createGroupChat.class);
        intent.putExtra("groupId", groupId);
        intent.putExtra("groupName", groupChatModel.getChatroomName());
        intent.putExtra("alreadyCreated", true);
        startActivity(intent);
    }

    private void setupRecyclerView() {
        String selectedLanguage = preferences.getString("selected_language", "en");
        boolean isTranslationEnabled = preferences.getBoolean("translation_enabled", false);

        Query query = FireBaseUtil.getGroupChatMessagesReference(groupChatModel.getChatroomId())
                .orderBy("timestamp", Query.Direction.ASCENDING);

        FirestoreRecyclerOptions<GroupChatMessageModel> options = new FirestoreRecyclerOptions.Builder<GroupChatMessageModel>()
                .setQuery(query, GroupChatMessageModel.class).build();

        adapter = new GroupChatRecyclerAdapter(options, GroupChatTexting.this, selectedLanguage, isTranslationEnabled);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(20);

        LinearLayoutManager manager = new LinearLayoutManager(this);
        manager.setStackFromEnd(true);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        adapter.startListening();

        adapter.setOnImageClickListener(this::showFullScreenImage); // Set the OnImageClickListener here

        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                scrollToBottom();
            }
        });

        scrollToBottom();
    }

    private void sendMessageToGroup(String message) {
        GroupChatMessageModel chatMessageModel = new GroupChatMessageModel();
        FireBaseUtil.currentUserDetails().get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                userModel = task.getResult().toObject(UserModel.class);
                if (userModel != null) {
                    chatMessageModel.setSenderUsername(userModel.getUsername());
                }
            }
        });

        if (message.isEmpty()) {
            return;
        }

        String groupId = groupChatModel.getChatroomId();
        String currentUserId = FireBaseUtil.currentUSerId();
        Timestamp timestamp = Timestamp.now();


        chatMessageModel.setMessage(message);
        chatMessageModel.setSenderId(currentUserId);
        chatMessageModel.setTimestamp(timestamp);

        chatMessageModel.setMessageType("text");

        FireBaseUtil.getGroupChatReference(groupId).update(
                "lastMessage", message,
                "lastMessageSenderId", currentUserId,
                "lastMessageTimestamp", timestamp
        );

        FireBaseUtil.getGroupChatMessagesReference(groupId).add(chatMessageModel)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        binding.chatMessageInput.setText("");
                        // Notify all users in the group
                        notifyGroupUsers(message);
                    } else {
                    }
                });
    }

    private void notifyGroupUsers(String message) {
        List<String> userIds = groupChatModel.getUserIds();
        for (String userId : userIds) {
            if (!userId.equals(FireBaseUtil.currentUSerId())) {
                Log.i("GAG", "notifyGroupUsers: " + userId + userIds);
                FireBaseUtil.getOneSignalExternalId(userId).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String oneSignalExternalId = task.getResult();
                        Log.i("GAG", "notifyGroupUsers: " + oneSignalExternalId);
                        if (oneSignalExternalId != null) {
                            OneSignalManager.sendNotification(groupChatModel.getChatroomName(), message, oneSignalExternalId);
                        }
                    } else
                        Log.i("GAG", "notifyGroupUsers: " + task.getException());
                });
            }
        }
    }


    private void leaveGroup() {
        FireBaseUtil.getGroupChatReference(groupId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                groupChatModel = task.getResult().toObject(GroupChatModel.class);
                if (groupChatModel != null) {
                    groupChatModel.getUserIds().remove(FireBaseUtil.currentUSerId());
                    FireBaseUtil.getGroupChatReference(groupId).set(groupChatModel);
                    Intent intent = new Intent(GroupChatTexting.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            }
        });


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_DOCUMENT_REQUEST && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri documentUri = data.getData();
                showRenameDialog(documentUri);
            }
        } else if (requestCode == PICK_CONTACT_REQUEST && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri contactUri = data.getData();
                Log.i("TAG", "sendContactMessage: " + groupId + "\n" + contactUri);

                MessageUtil.sendContactMessage(this, contactUri, groupChatModel.getChatroomId(), true);
            }
        }
    }

    private void sendDocumentMessage(Uri documentUri, String newFileName) {
        String fileExtension = AndroidUtil.getFileExtension(this, documentUri);

        StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child("Document Files")
                .child(groupId)
                .child(System.currentTimeMillis() + "." + fileExtension);

        storageReference.putFile(documentUri).addOnSuccessListener(taskSnapshot -> {
            storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                String documentUrl = uri.toString();
                sendDocumentMessageToUser(documentUrl, newFileName + "." + fileExtension, fileExtension);
            });
        }).addOnFailureListener(e -> {
            AndroidUtil.showToastShort(GroupChatTexting.this, "Failed to upload document");
        });
    }

    private void showFullScreenImage(String imageUrl) {
        Dialog dialog = new Dialog(this, R.style.FullScreenDialogStyle);
        dialog.setContentView(R.layout.dialog_fullscreen_image);

        PhotoView fullscreenImageView = dialog.findViewById(R.id.fullscreen_image_view);
        Button saveButton = dialog.findViewById(R.id.save_image_button);

        Glide.with(this)
                .load(imageUrl)
                .into(fullscreenImageView);

        saveButton.setOnClickListener(v -> saveImageToDevice(imageUrl));

        dialog.show();
    }

    private void saveImageToDevice(String imageUrl) {
        this.currentImageUrl = imageUrl;  // Store the current image URL
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    STORAGE_PERMISSION_CODE);
        } else {
            downloadAndSaveImage(imageUrl);
        }
    }

    private void downloadAndSaveImage(String imageUrl) {
        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        String fileName = "SmartChat_" + System.currentTimeMillis() + ".jpg";
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);

                        ContentResolver resolver = getContentResolver();
                        Uri imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

                        try {
                            OutputStream outStream = resolver.openOutputStream(imageUri);
                            resource.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                            outStream.close();
                            AndroidUtil.showToastShort(GroupChatTexting.this, "Image saved successfully");
                        } catch (Exception e) {
                            AndroidUtil.showToastShort(GroupChatTexting.this, "Failed to save image");
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }

                });
    }


    private void sendDocumentMessageToUser(String documentUrl, String fileName, String fileExtension) {
        groupChatModel.setLastMessageTimestamp(Timestamp.now());
        groupChatModel.setLastMessageSenderId(FireBaseUtil.currentUSerId());
        groupChatModel.setLastMessage(fileName);
        FireBaseUtil.getGroupChatReference(groupId).set(groupChatModel);


        FireBaseUtil.currentUserDetails().get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                userModel = task.getResult().toObject(UserModel.class);
                if (userModel != null) {
                    GroupChatMessageModel groupChatMessageModel = new GroupChatMessageModel(documentUrl, FireBaseUtil.currentUSerId(), userModel.getUsername(), Timestamp.now());
                    groupChatMessageModel.setMessageType("document");
                    groupChatMessageModel.setFileName(fileName);

                    groupChatMessageModel.setFileExtension(fileExtension);
                    FireBaseUtil.getGroupChatMessagesReference(groupId).add(groupChatMessageModel)
                            .addOnCompleteListener(task2 -> {
                                if (task2.isSuccessful()) {
                                    AndroidUtil.showToastShort(GroupChatTexting.this, "Document sent successfully");
                                }
                            });
                }
            }
        });


    }


    private void showRenameDialog(Uri documentUri) {
        // Create an AlertDialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Rename Document");

        // Set up the input
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", (dialog, which) -> {
            String newFileName = input.getText().toString().trim();
            if (!newFileName.isEmpty()) {
                sendDocumentMessage(documentUri, newFileName);
            } else {
                AndroidUtil.showToastShort(GroupChatTexting.this, "File name cannot be empty");
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }


}
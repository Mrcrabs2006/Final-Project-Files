package com.example.smartchat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.adapter.SearchUserRecyclerAdapter;
import com.example.smartchat.databinding.ActivitySearchUserBinding;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import timber.log.Timber;

public class SearchUserActivity extends AppCompatActivity {

    ActivitySearchUserBinding binding;
    SearchUserRecyclerAdapter adapter;
    RecyclerView recyclerView;
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        recyclerView = binding.chatRecyclerView;
        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (recyclerView == null) {
            Log.e("SearchUserActivity", "RecyclerView is null");
        }

        binding.fabSearch.requestFocus();


        binding.fabGetUsersFromContacts.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_CONTACTS},
                        PERMISSIONS_REQUEST_READ_CONTACTS);
            } else {
                getContactsAndSearch();
            }
        });

        binding.backBtn.setOnClickListener((v) -> {
            Intent intent = new Intent(SearchUserActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });


        binding.fabSearch.setOnClickListener((v -> {
            String searchTerm = binding.searchEditText.getText().toString();
            if (searchTerm.isEmpty() || searchTerm.length() < 3) {
                binding.searchEditText.setError("Invalid Username");
                return;
            }

            if (searchTerm.contains("+")) {
                setupSearchRecyclerViewPhone(searchTerm);
                return;
            } else

                setupSearchRecyclerView(searchTerm);

        }));


    }

    private void getContactsAndSearch() {
        List<String> phoneNumbers = getPhoneNumbers();
        searchUsersFromContacts(phoneNumbers);
    }


    private void searchUsersFromContacts(List<String> phoneNumbers) {
        final int BATCH_SIZE = 10;
        final List<UserModel> allMatchingUsers = new ArrayList<>();

        for (int i = 0; i < phoneNumbers.size(); i += BATCH_SIZE) {
            int end = Math.min(i + BATCH_SIZE, phoneNumbers.size());
            List<String> batch = phoneNumbers.subList(i, end);

            Query query = FireBaseUtil.allUsersCollectionReference()
                    .whereIn("phone", batch);

            query.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    QuerySnapshot querySnapshot = task.getResult();
                    if (querySnapshot != null && !querySnapshot.isEmpty()) {
                        for (UserModel user : querySnapshot.toObjects(UserModel.class)) {
                            allMatchingUsers.add(user);
                        }
                    }

                    // If this is the last batch, update the UI
                    if (end == phoneNumbers.size()) {
                        updateUIWithResults(allMatchingUsers);
                    }
                } else {
                    AndroidUtil.showToastShort(SearchUserActivity.this, "Error loading data");
                }
            });
        }
    }


    private void updateUIWithResults(List<UserModel> users) {
        if (users.isEmpty()) {
            AndroidUtil.showToastShort(SearchUserActivity.this, "No matching users found in your contacts");
        } else {

            // Create a query that will always return these specific users
            Query query = FireBaseUtil.allUsersCollectionReference()
                    .whereIn("userId", getUserIds(users));

            FirestoreRecyclerOptions<UserModel> options = new FirestoreRecyclerOptions.Builder<UserModel>()
                    .setQuery(query, UserModel.class)
                    .build();

            adapter = new SearchUserRecyclerAdapter(options, getApplicationContext());
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(adapter);
            adapter.startListening();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_REQUEST_READ_CONTACTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getContactsAndSearch();
            } else {
                AndroidUtil.showToastShort(this, "Permission denied to read your contacts");
            }
        }
    }

    private List<String> getUserIds(List<UserModel> users) {
        List<String> userIds = new ArrayList<>();
        for (UserModel user : users) {
            userIds.add(user.getUserId());
        }
        return userIds;
    }


    private List<String> getPhoneNumbers() {
        List<String> phoneNumbers = new ArrayList<>();
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                null,
                null,
                null
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                phoneNumber = phoneNumber.replaceAll("[\\s\\-()]", ""); // Normalize the phone number
                phoneNumbers.add(phoneNumber);
            }
            cursor.close();
        }

        Timber.tag("phoneNumbers").i("getPhoneNumbers: " + phoneNumbers);

        return phoneNumbers;
    }


    private void setupSearchRecyclerViewPhone(String searchTerm) {

        Query query = FireBaseUtil.allUsersCollectionReference()
                .whereGreaterThanOrEqualTo("phone", searchTerm)
                .whereLessThanOrEqualTo("phone", searchTerm + "\uf8ff");

        FirestoreRecyclerOptions<UserModel> options = new FirestoreRecyclerOptions.Builder<UserModel>()
                .setQuery(query, UserModel.class).build();

        adapter = new SearchUserRecyclerAdapter(options, getApplicationContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        adapter.startListening();

        // Check for empty results once the data is loaded
        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                if (task.getResult().isEmpty()) {
                    // No items found, show toast
                    AndroidUtil.showToastShort(SearchUserActivity.this, "User not found");
                }
            } else {
                // Handle the error if needed
                AndroidUtil.showToastShort(SearchUserActivity.this, "Error loading data");
            }
        });
    }


    private void setupSearchRecyclerView(String searchTerm) {

        Query query = FireBaseUtil.allUsersCollectionReference()
                .whereGreaterThanOrEqualTo("username", searchTerm)
                .whereLessThanOrEqualTo("username", searchTerm + "\uf8ff");

        FirestoreRecyclerOptions<UserModel> options = new FirestoreRecyclerOptions.Builder<UserModel>()
                .setQuery(query, UserModel.class).build();

        adapter = new SearchUserRecyclerAdapter(options, getApplicationContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        adapter.startListening();

        // Add a listener to check if any items are found
        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                if (task.getResult().isEmpty()) {
                    // No items found, show toast
                    AndroidUtil.showToastShort(SearchUserActivity.this, "User not found");
                }
            } else {
                // Handle the error if needed
                AndroidUtil.showToastShort(SearchUserActivity.this, "Error loading data");
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adapter != null) {
            adapter.startListening();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.startListening();

        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (adapter != null) {
            adapter.startListening();

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (adapter != null) {
            adapter.startListening();
        }
    }
}
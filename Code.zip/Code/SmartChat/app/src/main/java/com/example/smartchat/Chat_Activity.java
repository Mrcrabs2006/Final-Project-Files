package com.example.smartchat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.smartchat.adapter.ChatRecyclerAdapter;
import com.example.smartchat.databinding.ActivityChatBinding;
import com.example.smartchat.model.ChatMessageModel;
import com.example.smartchat.model.ChatRoomModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.EncryptionUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.example.smartchat.utils.MessageUtil;
import com.example.smartchat.utils.SpeechToTextUtil;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.github.chrisbanes.photoview.PhotoView;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.color.utilities.DynamicColor;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.zegocloud.uikit.plugin.invitation.ZegoInvitationType;
import com.zegocloud.uikit.prebuilt.call.invite.widget.ZegoSendCallInvitationButton;
import com.zegocloud.uikit.service.defines.ZegoUIKitUser;

import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class Chat_Activity extends AppCompatActivity {
    ActivityChatBinding binding;
    UserModel otherUser;
    String otherUserName;
    String chatRoomId;
    ChatRoomModel chatRoomModel;
    ChatRecyclerAdapter adapter;
    RecyclerView recyclerView;
    private SharedPreferences preferences;
    Switch featureSwitch;
    private ActivityResultLauncher<Intent> pickImageLauncher;
    boolean isBlocked;
    private LottieAnimationView loadingLottieView;
    ActivityResultLauncher<Intent> imagePickLauncher;
    Uri selectedImageUri;
    private String currentImageUrl;


    private static final int STORAGE_PERMISSION_CODE = 100;
    private static final int PICK_DOCUMENT_REQUEST = 1;
    private static final int PICK_CONTACT_REQUEST = 2;
    public static final int RESULT_SPEECH = 4;
    public static final int READ_CONTACTS_PERMISSION_CODE =5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        otherUser = AndroidUtil.getUserModelFromIntent(getIntent());
        chatRoomId = FireBaseUtil.getChatroomId(FireBaseUtil.currentUSerId(), otherUser.getUserId());
        recyclerView = binding.chatRecyclerView;
        preferences = getSharedPreferences("ChatPrefs", Context.MODE_PRIVATE);
        checkIfUserIsBlocked();
        loadingLottieView = findViewById(R.id.loading_Ai);

        AnimationUtils.controlLottieAnimation(this, binding.toolbar.callBtn);



        imagePickLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) {
                Intent data = result.getData();
                if (data != null && data.getData() != null) {
                    selectedImageUri = data.getData();

                    if (selectedImageUri != null) {
                        sendImageMessage(selectedImageUri);
                    } else {
                        AndroidUtil.showToastShort(Chat_Activity.this, "Error");
                    }
                }
            }
        });

        AtomicReference<String> currentUserId = new AtomicReference<>(FireBaseUtil.currentUSerId());


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_chat), (v, insets) -> {
            // Get system bars insets
            Insets systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Apply padding only to left, top, and right
            v.setPadding(systemBarsInsets.left, systemBarsInsets.top, systemBarsInsets.right, insets.getSystemWindowInsetBottom());

            // Return the insets to indicate they have been consumed
            return WindowInsetsCompat.CONSUMED;
        });


        binding.toolbar.userNameTxt.setOnClickListener(v -> {
            Intent intent = new Intent(this, OtherUserProfileActivity.class);
            intent.putExtra("otherUserId", otherUser.getUserId());
            startActivity(intent);
        });

        binding.toolbar.speechToText.setOnClickListener(v -> {
            SpeechToTextUtil.startSpeechToText(Chat_Activity.this);
        });


        binding.toolbar.moreOptions.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(Chat_Activity.this, v);
            popupMenu.getMenuInflater().inflate(R.menu.chat_room_options_menu, popupMenu.getMenu());

            popupMenu.getMenu().findItem(R.id.blockUser).setVisible(!isBlocked);
            popupMenu.getMenu().findItem(R.id.unBlock).setVisible(isBlocked);

            popupMenu.setOnMenuItemClickListener(item -> {
                if (isBlocked) {
                    AndroidUtil.showToastShort(Chat_Activity.this, "You have blocked this user and cannot send messages.");
                    return true;
                }

                if (item.getItemId() == R.id.blockUser) {
                    blockUser(otherUser.getUserId());
                    return true;
                } else if (item.getItemId() == R.id.unBlock) {
                    unblockUser(otherUser.getUserId());
                    return true;
                } else if (item.getItemId() == R.id.sendDocument) {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("*/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(intent, "Select Document"), PICK_DOCUMENT_REQUEST);
                    return true;
                } else if (item.getItemId() == R.id.sendContact) {
                    Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                    startActivityForResult(intent, PICK_CONTACT_REQUEST);
                    return true;
                }
                return false;
            });

            popupMenu.show();
        });

        binding.toolbar.callBtn.setOnClickListener(v -> {

            showCallOptionsDialog(otherUser);


        });


        binding.toolbar.translate.setOnClickListener(v -> {
            // Inflate the custom layout
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View popupView = inflater.inflate(R.layout.popup_menu_layout, null);

            // Get the RadioGroup and set the checked radio button based on the saved preference
            RadioGroup languageRadioGroup = popupView.findViewById(R.id.language_radio_group);

            // Get the switch and set its state from shared preferences
            featureSwitch = popupView.findViewById(R.id.feature_switch);

            featureSwitch.setChecked(preferences.getBoolean("translation_enabled", false));

            // Set the checked radio button based on saved language preference
            String selectedLanguage = preferences.getString("selected_language", "English");
            switch (selectedLanguage) {
                case "Arabic":
                    languageRadioGroup.check(R.id.radio_arabic);
                    break;
                case "Spanish":
                    languageRadioGroup.check(R.id.radio_spanish);
                    break;
                case "French":
                    languageRadioGroup.check(R.id.radio_french);
                    break;
                case "English":
                default:
                    languageRadioGroup.check(R.id.radio_english);
                    break;
            }

            // Create a popup window
            PopupWindow popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
            popupWindow.showAsDropDown(v);

            // Set a click listener for the switch
            featureSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("translation_enabled", isChecked);
                editor.apply();

                // Update the adapter
                adapter.setTranslationEnabled(isChecked);
            });

            languageRadioGroup.setOnCheckedChangeListener((group, checkedId) -> {
                String sL = "";

                if (checkedId == R.id.radio_arabic) {
                    sL = "ar";
                } else if (checkedId == R.id.radio_spanish) {
                    sL = "es";  // Note: "sp" is not a valid language code, "es" is for Spanish
                } else if (checkedId == R.id.radio_french) {
                    sL = "fr";
                } else if (checkedId == R.id.radio_english) {
                    sL = "en";
                }

                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("selected_language", sL);
                editor.apply();

                // Update the adapter
                adapter.setSelectedLanguage(sL);
            });
        });

        binding.messageSendBtn.setOnClickListener(v -> {
            if (isBlocked) {
                AndroidUtil.showToastShort(Chat_Activity.this, "You have blocked this user and cannot send messages.");
                return;
            }

            String message = binding.chatMessageInput.getText().toString().trim();

            if (message.isEmpty()) {
                return;
            }

// Check if the message starts with "/prompt"
            if (message.startsWith("/prompt")) {
                // Extract the AI prompt after "/prompt"
                String aiPrompt = message.substring(7).trim();

                // Ensure the prompt is not empty
                if (!aiPrompt.isEmpty()) {
                    // Set loading animation visibility to true (or start it)
                    setLoadingLottieVisibility(true);

                    // Send the extracted prompt to the AI service
                    testAi(aiPrompt);
                } else {
                    // Show a toast message if no prompt is provided after "/prompt"
                    AndroidUtil.showToastShort(Chat_Activity.this, "Please provide a prompt after /prompt");
                }

                // Exit the method to prevent further processing
                return;
            }

            // Check if the other user has blocked the current user
            currentUserId.set(FireBaseUtil.currentUSerId());
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            DocumentReference otherUserRef = db.collection("users").document(otherUser.getUserId());
            otherUserRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    List<String> blockedUsers = (List<String>) task.getResult().get("blockedUsers");

                    // Check if the current user is blocked by the other user
                    if (blockedUsers != null && blockedUsers.contains(currentUserId)) {
                        AndroidUtil.showToastShort(Chat_Activity.this, "You are blocked by this user and cannot send messages.");
                    } else {
                        // send message the message if not blocked
                        FireBaseUtil.getUserDetails(otherUser.getUserId()).get().addOnCompleteListener(userTask -> {
                            if (userTask.isSuccessful()) {
                                UserModel otherUserModelNoti = userTask.getResult().toObject(UserModel.class);
                                assert otherUserModelNoti != null;


                                FireBaseUtil.getUserDetails(FireBaseUtil.currentUSerId()).get().addOnCompleteListener(task2 -> {
                                    if (task2.isSuccessful() && task2.getResult() != null) {
                                        UserModel userModel = task2.getResult().toObject(UserModel.class);
                                        assert userModel != null;
                                        if (userModel.getUsername() != null) {
                                            OneSignalManager.sendNotification(userModel.getUsername(), message, otherUserModelNoti.getOneSignalExternalId());
                                        }
                                    }
                                });

                                // Send the notification

                            }
                        });

                        sendMessageToUser(message);
                    }
                } else {
                    // showing an error message
                    AndroidUtil.showToastShort(Chat_Activity.this, "Failed to check blocked status. Please try again.");
                }
            });
        });


        binding.toolbar.backBtn.setOnClickListener((v) -> {
            Intent intent = new Intent(Chat_Activity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        binding.attachImage.setOnClickListener(v -> {
            if (isBlocked) {
                AndroidUtil.showToastShort(Chat_Activity.this, "You have blocked this user and cannot send messages.");
                return;
            }

            ImagePicker.with(Chat_Activity.this).cropSquare().compress(512).maxResultSize(512, 512).createIntent(new Function1<Intent, Unit>() {
                @Override
                public Unit invoke(Intent intent) {
                    imagePickLauncher.launch(intent);
                    return null;
                }
            });
        });
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSION_CODE);
        }


        otherUserName = otherUser.getUsername();

        binding.toolbar.userNameTxt.setText(otherUserName);


        getOrCreateChatroomModel();
        setupRecyclerView();

        FireBaseUtil.getOtherProfilePicStorageRef(otherUser.getUserId()).getDownloadUrl()
                .addOnCompleteListener(task1 -> {
                    if (task1.isSuccessful() && task1.getResult() != null) {
                        Uri uri = task1.getResult();
                        AndroidUtil.setProfilePic(getApplicationContext(), uri, binding.toolbar.profilePicLayout.profilePicImageView);
                    } else {
                        binding.toolbar.profilePicLayout.profilePicImageView.setImageResource(R.drawable.chat_round);
                    }
                });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_CONTACT_REQUEST && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri contactUri = data.getData();
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                    MessageUtil.sendContactMessage(this, contactUri, chatRoomId, false);
                } else {
                    Toast.makeText(this, "Permission to read contacts is required to send contact messages.", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == SpeechToTextUtil.RESULT_SPEECH) {
            SpeechToTextUtil.handleSpeechResult(requestCode, resultCode, data, binding.chatMessageInput);
        }
    }



    private void sendDocumentMessage(Uri documentUri, String newFileName) {
        String fileExtension = AndroidUtil.getFileExtension(this, documentUri);

        StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child("Document Files")
                .child(chatRoomId)
                .child(System.currentTimeMillis() + "." + fileExtension);

        storageReference.putFile(documentUri).addOnSuccessListener(taskSnapshot -> {
            storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                String documentUrl = uri.toString();
                sendDocumentMessageToUser(documentUrl, newFileName + "." + fileExtension, fileExtension);
            });
        }).addOnFailureListener(e -> {
            AndroidUtil.showToastShort(Chat_Activity.this, "Failed to upload document");
        });
    }

    private void sendDocumentMessageToUser(String documentUrl, String fileName, String fileExtension) {
        chatRoomModel.setLastMessageTimestamp(Timestamp.now());
        chatRoomModel.setLastMessageSenderId(FireBaseUtil.currentUSerId());
        chatRoomModel.setLastMessage(fileName);
        FireBaseUtil.getChatroomReference(chatRoomId).set(chatRoomModel);

        ChatMessageModel chatMessageModel = new ChatMessageModel(documentUrl, FireBaseUtil.currentUSerId(), Timestamp.now());
        chatMessageModel.setMessageType("document");
        chatMessageModel.setFileName(fileName);

        chatMessageModel.setFileExtension(fileExtension);
        FireBaseUtil.getChatroomMessageReference(chatRoomId).add(chatMessageModel)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        AndroidUtil.showToastShort(Chat_Activity.this, "Document sent successfully");
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, retry saving the image
                saveImageToDevice(currentImageUrl);
            } else {
                AndroidUtil.showToastShort(this, "Storage permission is required to save images");
            }
        } else if (requestCode == READ_CONTACTS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with reading contacts
                // You can add your logic here to handle the contact reading
            } else {
                AndroidUtil.showToastShort(this, "Permission to read contacts is required to send contact messages.");
            }
        }
    }


    private void sendImageMessage(Uri imageUri) {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child("Image Files")
                .child(chatRoomId)
                .child(System.currentTimeMillis() + "." + AndroidUtil.getFileExtension(this, imageUri));

        storageReference.putFile(imageUri).addOnSuccessListener(taskSnapshot -> {
            storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                String imageUrl = uri.toString();
                sendImageMessageToUser(imageUrl);
            });
        }).addOnFailureListener(e -> {
            AndroidUtil.showToastShort(Chat_Activity.this, "Failed to upload image");
        });
    }

    private void sendImageMessageToUser(String imageUrl) {
        chatRoomModel.setLastMessageTimestamp(Timestamp.now());
        chatRoomModel.setLastMessageSenderId(FireBaseUtil.currentUSerId());
        chatRoomModel.setLastMessage("Image");
        FireBaseUtil.getChatroomReference(chatRoomId).set(chatRoomModel);

        ChatMessageModel chatMessageModel = new ChatMessageModel(imageUrl, FireBaseUtil.currentUSerId(), Timestamp.now());
        chatMessageModel.setMessageType("image");
        FireBaseUtil.getChatroomMessageReference(chatRoomId).add(chatMessageModel)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        AndroidUtil.showToastShort(Chat_Activity.this, "Image sent successfully");
                    }
                });
    }

    private void setLoadingLottieVisibility(boolean isVisible) {
        runOnUiThread(() -> {
            if (isVisible) {
                loadingLottieView.setVisibility(View.VISIBLE);
            } else {
                loadingLottieView.setVisibility(View.GONE);
            }
        });
    }




    private void showCallOptionsDialog(UserModel recipient) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Chat_Activity.this);
        View view = LayoutInflater.from(Chat_Activity.this).inflate(R.layout.user_bottom_sheet, null);
        bottomSheetDialog.setContentView(view);
        bottomSheetDialog.show();

        TextView userNameTV = view.findViewById(R.id.userNameTV);
        TextView userIdTV = view.findViewById(R.id.userIdTV);

        ZegoSendCallInvitationButton voiceCallBtn = view.findViewById(R.id.voiceCallBtn);
        ZegoSendCallInvitationButton videoCallBtn = view.findViewById(R.id.videoCallBtn);

        voiceCallBtn.setIsVideoCall(false);
        voiceCallBtn.setType(ZegoInvitationType.VOICE_CALL);
        voiceCallBtn.setResourceID("call");
        voiceCallBtn.setInvitees(Collections.singletonList(new ZegoUIKitUser(recipient.getUserId(), recipient.getUsername())));

        videoCallBtn.setIsVideoCall(true);
        videoCallBtn.setType(ZegoInvitationType.VIDEO_CALL);
        videoCallBtn.setResourceID("call");
        videoCallBtn.setInvitees(Collections.singletonList(new ZegoUIKitUser(recipient.getUserId(), recipient.getUsername())));

        userNameTV.setText(MessageFormat.format("User Name: {0}", recipient.getUsername()));
        userIdTV.setText(MessageFormat.format("User Phone: {0}", recipient.getPhone()));
    }


    private void unblockUser(String blockedUserId) {
        String currentUserId = FireBaseUtil.currentUSerId();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(currentUserId);

        userRef.update("blockedUsers", FieldValue.arrayRemove(blockedUserId))
                .addOnSuccessListener(aVoid -> {
                    Log.d("Chat_Activity", "User successfully unblocked");
                    AndroidUtil.showToastShort(Chat_Activity.this, "User unblocked successfully");
                    restartActivity(); // Restart activity after unblocking
                })
                .addOnFailureListener(e -> Log.w("Chat_Activity", "Error unblocking user", e));
    }

    private void checkIfUserIsBlocked() {
        String currentUserId = FireBaseUtil.currentUSerId();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(currentUserId);

        userRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                List<String> blockedUsers = (List<String>) task.getResult().get("blockedUsers");
                isBlocked = blockedUsers != null && blockedUsers.contains(otherUser.getUserId());
            } else {
                isBlocked = false;  // Default to not blocked if the check fails
            }
        });
    }

    private void testAi(String prompt) {
        // Initialize the generative model
        GenerativeModel gm = new GenerativeModel(
                /* modelName */ "gemini-1.5-flash",
                /* apiKey */ "AIzaSyCWD0AOjoVdxSDf3-V4nlT3p5HudwWy8VY"
        );

        // Use the GenerativeModelFutures Java compatibility layer
        GenerativeModelFutures model = GenerativeModelFutures.from(gm);

        // Create the content prompt
        Content content = new Content.Builder()
                .addText(prompt)
                .build();

        // Create an Executor for handling the asynchronous callbacks
        Executor executor = Executors.newSingleThreadExecutor();

        // Generate content asynchronously
        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);

        // Add a callback to handle success and failure
        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                runOnUiThread(() -> {
                    setLoadingLottieVisibility(false);
                    String resultText = result.getText();
                    binding.chatMessageInput.setText(resultText);
                });
            }

            @Override
            public void onFailure(Throwable t) {
                runOnUiThread(() -> {
                    setLoadingLottieVisibility(false);
                    AndroidUtil.showToastShort(Chat_Activity.this, "Failed to generate content");
                });
                t.printStackTrace();
            }
        }, executor);
    }


    // Method to block a user
    private void blockUser(String blockedUserId) {
        String currentUserId = FireBaseUtil.currentUSerId();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(currentUserId);

        userRef.update("blockedUsers", FieldValue.arrayUnion(blockedUserId))
                .addOnSuccessListener(aVoid -> {
                    Log.d("Chat_Activity", "User successfully blocked");
                    AndroidUtil.showToastShort(Chat_Activity.this, "User blocked successfully");
                    restartActivity();
                })
                .addOnFailureListener(e -> Log.w("Chat_Activity", "Error blocking user", e));
    }

    private void setupRecyclerView() {


        Query query = FireBaseUtil.getChatroomMessageReference(chatRoomId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(20); // Limit initial load to 20 messages

        FirestoreRecyclerOptions<ChatMessageModel> options = new FirestoreRecyclerOptions.Builder<ChatMessageModel>()
                .setQuery(query, ChatMessageModel.class).build();

        boolean isTranslationEnabled = preferences.getBoolean("translation_enabled", false);
        String selectedLanguage = preferences.getString("selected_language", "en");

        adapter = new ChatRecyclerAdapter(options, getApplicationContext(), otherUser, selectedLanguage, isTranslationEnabled,chatRoomModel);
        adapter.setOnImageClickListener(this::showFullScreenImage);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(20);


        LinearLayoutManager manager = new LinearLayoutManager(this);
        manager.setReverseLayout(true);
        manager.setStackFromEnd(true);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        adapter.startListening();

        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                int lastVisiblePosition = manager.findLastCompletelyVisibleItemPosition();
                if (lastVisiblePosition == -1 ||
                        (positionStart >= (adapter.getItemCount() - 1) && lastVisiblePosition == (positionStart - 1))) {
                    recyclerView.scrollToPosition(positionStart);
                }
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int firstVisibleItemPosition = manager.findFirstVisibleItemPosition();
                if (firstVisibleItemPosition <= 5) {
                    // Load next batch of messages if necessary
                }
            }
        });
    }


    private void sendMessageToUser(String message) {
        String receiverUID = otherUser.getUserId(); // Get the receiver's UID

        try {
            String encryptedMessage = EncryptionUtil.encrypt(message, receiverUID); // Encrypt the message
            sendEncryptedMessageToUser(encryptedMessage);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle encryption error
        }
    }

    private void showFullScreenImage(String imageUrl) {
        Dialog dialog = new Dialog(this, R.style.FullScreenDialogStyle);
        dialog.setContentView(R.layout.dialog_fullscreen_image);

        PhotoView fullscreenImageView = dialog.findViewById(R.id.fullscreen_image_view);
        Button saveButton = dialog.findViewById(R.id.save_image_button);

        Glide.with(this)
                .load(imageUrl)
                .into(fullscreenImageView);

        saveButton.setOnClickListener(v -> saveImageToDevice(imageUrl));

        dialog.show();
    }

    private void saveImageToDevice(String imageUrl) {
        this.currentImageUrl = imageUrl;  // Store the current image URL
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    STORAGE_PERMISSION_CODE);
        } else {
            downloadAndSaveImage(imageUrl);
        }
    }

    private void downloadAndSaveImage(String imageUrl) {
        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        String fileName = "SmartChat_" + System.currentTimeMillis() + ".jpg";
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);

                        ContentResolver resolver = getContentResolver();
                        Uri imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

                        try {
                            OutputStream outStream = resolver.openOutputStream(imageUri);
                            resource.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                            outStream.close();
                            AndroidUtil.showToastShort(Chat_Activity.this, "Image saved successfully");
                        } catch (Exception e) {
                            AndroidUtil.showToastShort(Chat_Activity.this, "Failed to save image");
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }

                });
    }




    private void sendEncryptedMessageToUser(String encryptedMessage) throws Exception {
        chatRoomModel.setLastMessageTimestamp(Timestamp.now());
        chatRoomModel.setLastMessageSenderId(FireBaseUtil.currentUSerId());
        chatRoomModel.setLastMessage(encryptedMessage);
        FireBaseUtil.getChatroomReference(chatRoomId).set(chatRoomModel);

        ChatMessageModel chatMessageModel = new ChatMessageModel(encryptedMessage, FireBaseUtil.currentUSerId(), Timestamp.now());
        FireBaseUtil.getChatroomMessageReference(chatRoomId).add(chatMessageModel)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()) {
                            binding.chatMessageInput.setText("");
                        }
                    }
                });
    }


    void getOrCreateChatroomModel() {
        FireBaseUtil.getChatroomReference(chatRoomId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                chatRoomModel = task.getResult().toObject(ChatRoomModel.class);
                if (chatRoomModel == null) {
                    //first time chat
                    chatRoomModel = new ChatRoomModel(
                            chatRoomId,
                            Arrays.asList(FireBaseUtil.currentUSerId(), otherUser.getUserId()),
                            Timestamp.now(),
                            ""
                    );
                    FireBaseUtil.getChatroomReference(chatRoomId).set(chatRoomModel);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Chat_Activity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void restartActivity() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }


}
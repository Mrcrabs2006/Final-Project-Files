package com.example.smartchat.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.GroupChatTexting;
import com.example.smartchat.R;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.EncryptionUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

public class RecentGroupChatAdapter extends FirestoreRecyclerAdapter<GroupChatModel, RecentGroupChatAdapter.GroupChatModelViewHolder> {

    Context context;
    List<GroupChatModel> groupChats = new ArrayList<>();
    final int MAX_MESSAGE_LENGTH = 50;

    public RecentGroupChatAdapter(@NonNull FirestoreRecyclerOptions<GroupChatModel> options, Context context) {
        super(options);
        this.context = context;
        fetchGroupChats();
    }

    private void fetchGroupChats() {
        Query query = FireBaseUtil.allGroupChatCollectionReference();
        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                for (GroupChatModel groupChat : task.getResult().toObjects(GroupChatModel.class)) {
                    if (groupChat.getUserIds().contains(FireBaseUtil.currentUSerId())) {
                        groupChats.add(groupChat);
                    }
                }
                notifyDataSetChanged();
            } else {
                Log.e("RecentGroupChatAdapter", "Error fetching group chats", task.getException());
            }
        });
    }

    @NonNull
    @Override
    public GroupChatModelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_container_user_recent, parent, false);
        return new GroupChatModelViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onBindViewHolder(@NonNull GroupChatModelViewHolder holder, int position, @NonNull GroupChatModel model) {
        List<String> userIds = model.getUserIds();

        if (model.getUserIds() != null) {
            holder.groupName.setText(model.getChatroomName());
            Timber.tag("groupchat").i(model.getChatroomName());

            String lastMessageSenderId = model.getLastMessageSenderId();
            String lastMessage = model.getLastMessage();
            if (!lastMessageSenderId.isEmpty() && !lastMessage.isEmpty()) {
                boolean lastMessageSentByMe = lastMessageSenderId.equals(FireBaseUtil.currentUSerId());

                try {

                    String truncatedMessage = truncateMessage(lastMessage, MAX_MESSAGE_LENGTH);
                    holder.lastMessage.setText(lastMessageSentByMe ? "You: " + truncatedMessage : truncatedMessage);
                } catch (Exception e) {
                    holder.lastMessage.setText("Unable to decrypt message");
                }
            } else {
                holder.lastMessage.setText("No messages yet");
            }

            holder.timeStamp.setText(FireBaseUtil.timestampToString(model.getLastMessageTimestamp()));
        } else {
            holder.groupName.setText("No users in this chat");
            holder.lastMessage.setText("No messages yet");
            holder.timeStamp.setText("");
            holder.profilePic.setImageResource(R.drawable.profile_round);

        }

        holder.itemView.setOnClickListener(v -> {
            if (userIds != null) {
                Intent intent = new Intent(context, GroupChatTexting.class);
                AndroidUtil.passGroupChatAsIntent(intent, model);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } else {
                Log.d("RecentGroupChatAdapter", "No users in this chat to open chat activity");
            }
        });
    }

    private String truncateMessage(String message, int maxLength) {
        if (message.length() <= maxLength) {
            return message;
        }
        return message.substring(0, maxLength - 3) + "...";
    }

    @Override
    public int getItemCount() {
        return groupChats.size();
    }

    static class GroupChatModelViewHolder extends RecyclerView.ViewHolder {
        TextView groupName;
        TextView lastMessage;
        TextView timeStamp;
        ImageView profilePic;

        public GroupChatModelViewHolder(@NonNull View itemView) {
            super(itemView);
            groupName = itemView.findViewById(R.id.userName_txt);
            profilePic = itemView.findViewById(R.id.img_user);
            lastMessage = itemView.findViewById(R.id.lastMessage_txt);
            timeStamp = itemView.findViewById(R.id.timeStamp_txt);
        }
    }
}
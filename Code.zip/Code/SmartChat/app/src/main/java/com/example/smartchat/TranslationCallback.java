package com.example.smartchat;

public interface TranslationCallback {
    void onTranslationSuccess(String translatedText);
    void onTranslationError(String error);
}
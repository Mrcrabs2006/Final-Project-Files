package com.example.smartchat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.smartchat.databinding.ActivityOtherUserProfileBinding;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;


public class OtherUserProfileActivity extends AppCompatActivity {

    ActivityOtherUserProfileBinding binding;

    UserModel otherUser;
    String otherUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOtherUserProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        otherUserId = getIntent().getStringExtra("otherUserId");
        if (otherUserId == null) {
            AndroidUtil.showToastShort(this, "User ID not found");
            finish();
            return;
        }

        loadUserData();
    }

    private void loadUserData() {
        FireBaseUtil.getUserDetails(otherUserId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                otherUser = task.getResult().toObject(UserModel.class);
                if (otherUser != null) {
                    updateUI();
                } else {
                    AndroidUtil.showToastShort(this, "User not found");
                    finish();
                }
            } else {
                AndroidUtil.showToastShort(this, "Error Finding User Data");
                finish();
            }
        });
    }

    private void updateUI() {
        binding.profileUsername.setText(otherUser.getUsername());
        binding.phoneNumber.setText(otherUser.getPhone());
        binding.status.setText(otherUser.getStatus());

        FireBaseUtil.getOtherProfilePicStorageRef(otherUser.getUserId()).getDownloadUrl()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        Uri uri = task.getResult();
                        AndroidUtil.setProfilePic(getApplicationContext(), uri, binding.profileImageView);
                    } else {
                        binding.profileImageView.setImageResource(R.drawable.chat_round);
                    }
                });
    }




}
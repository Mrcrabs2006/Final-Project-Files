package com.example.smartchat.model;


import com.google.firebase.Timestamp;

import java.util.ArrayList;
import java.util.List;

public class GroupChatModel {
    String chatroomId;
    String chatroomName;  // New field for the chat room's name
    List<String> userIds;
    List<String> adminIds;  // New field for group admins
    Timestamp createdAt;  // New field for the creation time
    Timestamp lastMessageTimestamp;
    String lastMessageSenderId;
    String lastMessage;

    public GroupChatModel() {
        this.chatroomId = "";
        this.chatroomName = "";  // Initialize with default value
        this.userIds = new ArrayList<>();
        this.adminIds = new ArrayList<>();  // Initialize with an empty list
        this.createdAt = Timestamp.now();  // Set to current time
        this.lastMessageTimestamp = Timestamp.now();
        this.lastMessageSenderId = "";
        this.lastMessage = "";
    }

    public GroupChatModel(String chatroomId, String chatroomName, List<String> userIds, List<String> adminIds, Timestamp createdAt, Timestamp lastMessageTimestamp, String lastMessageSenderId) {
        this.chatroomId = chatroomId != null ? chatroomId : "";
        this.chatroomName = chatroomName != null ? chatroomName : "";  // Assign the chat room name
        this.userIds = userIds != null ? userIds : new ArrayList<>();
        this.adminIds = adminIds != null ? adminIds : new ArrayList<>();  // Assign the admins list
        this.createdAt = createdAt != null ? createdAt : Timestamp.now();  // Assign the creation time
        this.lastMessageTimestamp = lastMessageTimestamp != null ? lastMessageTimestamp : Timestamp.now();
        this.lastMessageSenderId = lastMessageSenderId != null ? lastMessageSenderId : "";
        this.lastMessage = "";
    }

    // Getters and setters

    public String getChatroomId() {
        return chatroomId != null ? chatroomId : "";
    }

    public void setChatroomId(String chatroomId) {
        this.chatroomId = chatroomId;
    }

    public String getChatroomName() {
        return chatroomName != null ? chatroomName : "";
    }

    public List<String> getUserIds() {
        return userIds != null ? userIds : new ArrayList<>();
    }

    public List<String> getAdminIds() {
        return adminIds != null ? adminIds : new ArrayList<>();
    }


    public Timestamp getCreatedAt() {
        return createdAt != null ? createdAt : Timestamp.now();
    }

    public Timestamp getLastMessageTimestamp() {
        return lastMessageTimestamp != null ? lastMessageTimestamp : Timestamp.now();
    }

    public String getLastMessageSenderId() {
        return lastMessageSenderId != null ? lastMessageSenderId : "";
    }

    public String getLastMessage() {
        return lastMessage != null ? lastMessage : "";
    }

    public void setChatroomName(String chatroomName) {
        this.chatroomName = chatroomName;
    }

    public void setUserIds(List<String> userIds) {
        this.userIds = userIds;
    }

    public void setAdminIds(List<String> adminIds) {
        this.adminIds = adminIds;
    }


    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public void setLastMessageTimestamp(Timestamp lastMessageTimestamp) {
        this.lastMessageTimestamp = lastMessageTimestamp;
    }

    public void setLastMessageSenderId(String lastMessageSenderId) {
        this.lastMessageSenderId = lastMessageSenderId;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }
}


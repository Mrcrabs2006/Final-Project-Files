package com.example.smartchat;

import static android.content.ContentValues.TAG;
import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.onesignal.Continue;
import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;
import com.zegocloud.uikit.prebuilt.call.ZegoUIKitPrebuiltCallService;
import com.zegocloud.uikit.prebuilt.call.config.ZegoNotificationConfig;
import com.zegocloud.uikit.prebuilt.call.invite.ZegoUIKitPrebuiltCallInvitationConfig;
import com.zegocloud.uikit.prebuilt.call.invite.internal.ZegoTranslationText;
import com.zegocloud.uikit.service.defines.ZegoUIKitUser;

public class SplashActivity extends AppCompatActivity {

    private int CurrentProgress = 0;
    private ProgressBar progressBar;
    private static final String ONESIGNAL_APP_ID = "your onesignal api key";
    private LottieAnimationView lottieAnimationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // Verbose Logging set to help debug issues, remove before releasing your app.
        OneSignal.getDebug().setLogLevel(LogLevel.VERBOSE);

        // OneSignal Initialization
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);

        // Request notification permission
        OneSignal.getNotifications().requestPermission(false, Continue.none());

        setContentView(R.layout.activity_splash);
        progressBar = findViewById(R.id.progressBar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Zego Call Service
        initializeCallService();

        if (getIntent().getExtras() != null) {
            String userId = getIntent().getExtras().getString("oneSignalExternalId");
            if (userId != null) {
                FireBaseUtil.allUsersCollectionReference().document(userId).get()
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                startprogressBarNoti(progressBar);
                                UserModel model = task.getResult().toObject(UserModel.class);
                                Intent intent = new Intent(this, Chat_Activity.class);
                                if (model != null) {
                                    AndroidUtil.passUserModelAsIntent(intent, model);
                                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Log.e(TAG, "UserModel is null");
                                    startprogressBar(progressBar);
                                }
                            } else {
                                Log.e(TAG, "Error getting user details: " + task.getException().getMessage());
                                startprogressBar(progressBar);
                            }
                        });
            } else {
                Log.e(TAG, "User ID is null from intent extras");
                startprogressBar(progressBar);
            }
        } else {
            startprogressBar(progressBar);
        }
    }

    private void initializeCallService() {
        long appID = getResources().getInteger(R.integer.app_id);
        String appSign = getString(R.string.app_sign);
        String currentUserId = FireBaseUtil.currentUSerId();

        if (currentUserId != null) {
            FireBaseUtil.getUserDetails(currentUserId).get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    UserModel user = task.getResult().toObject(UserModel.class);
                    if (user != null) {
                        ZegoUIKitPrebuiltCallInvitationConfig callInvitationConfig = new ZegoUIKitPrebuiltCallInvitationConfig();

                        ZegoNotificationConfig notificationConfig = new ZegoNotificationConfig();
                        notificationConfig.sound = "zego_uikit_sound_call";
                        notificationConfig.channelID = "CallInvitation";
                        notificationConfig.channelName = "CallInvitation";
                        callInvitationConfig.notificationConfig = notificationConfig;



                        ZegoUIKitUser currentUser = new ZegoUIKitUser(user.getUserId(), user.getUsername());

                        ZegoUIKitPrebuiltCallService.init(
                                getApplication(),
                                appID,
                                appSign,
                                currentUser.userID,
                                currentUser.userName,
                                callInvitationConfig
                        );
                        Log.e("callservice", "Call service initialized successfully in SplashActivity");
                    } else {
                        Log.e("callservice", "Failed to initialize call service: User is null");
                    }
                } else {
                    Log.e("callservice", "Failed to initialize call service: " + task.getException().getMessage());
                }
            });
        } else {
            Log.e("callservice", "currentUserId is null, cannot initialize call service.");
        }
    }


    private void startprogressBar(ProgressBar progressBar) {
        progressBar.setMax(100);
        new CountDownTimer(1000, 10) {
            @Override
            public void onTick(long millisUntilFinished) {
                CurrentProgress += (100 / (3000 / 30));
                progressBar.setProgress(CurrentProgress);
            }

            @Override
            public void onFinish() {
                progressBar.setProgress(100);
                Intent intent;
                if (FireBaseUtil.isLoggedIn()) {
                    intent = new Intent(SplashActivity.this, MainActivity.class);
                } else {
                    intent = new Intent(SplashActivity.this, Login_WIth_Phone_Number.class);
                }
                startActivity(intent);
                finish();
            }
        }.start();
    }

    private void startprogressBarNoti(ProgressBar progressBar) {
        progressBar.setMax(100);
        new CountDownTimer(200, 2) {
            @Override
            public void onTick(long millisUntilFinished) {
                CurrentProgress += (100 / (200 / 2));
                progressBar.setProgress(CurrentProgress);
            }

            @Override
            public void onFinish() {}
        }.start();
    }
}

package com.example.smartchat;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.smartchat.databinding.ActivityVerficationBinding;
import com.example.smartchat.utils.AndroidUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class Verfication_Activity extends AppCompatActivity {

    ActivityVerficationBinding binding;
    String phoneNumber;
    FirebaseAuth auth = FirebaseAuth.getInstance();
    Long timeOut = 60L;
    String verficationCode;
    PhoneAuthProvider.ForceResendingToken resendingToken;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityVerficationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setupVerficationInputs();

        phoneNumber = getIntent().getStringExtra("phoneNumber");


        sendVerfication(phoneNumber,false);

        binding.verficationBtn.setOnClickListener(v ->{
            String verficationCodeInput  = binding.verficationCodeText1.getText().toString() +
                    binding.verficationCodeText2.getText().toString() + binding.verficationCodeText3.getText().toString() +
                    binding.verficationCodeText4.getText().toString() + binding.verficationCodeText5.getText().toString() +
                    binding.verficationCodeText6.getText().toString();

            PhoneAuthCredential credential =  PhoneAuthProvider.getCredential(verficationCode,verficationCodeInput);
            signIn(credential);
            setProgresBar(true);

        });



        binding.resendCode.setOnClickListener((v)->{
            sendVerfication(phoneNumber,true);
        });





    }

    private void setupVerficationInputs(){
        binding.verficationCodeText1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!s.toString().trim().isEmpty()){
                    binding.verficationCodeText2.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.verficationCodeText2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!s.toString().trim().isEmpty()){
                    binding.verficationCodeText3.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.verficationCodeText3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!s.toString().trim().isEmpty()){
                    binding.verficationCodeText4.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.verficationCodeText4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!s.toString().trim().isEmpty()){
                    binding.verficationCodeText5.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.verficationCodeText5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!s.toString().trim().isEmpty()){
                    binding.verficationCodeText6.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }


    private void sendVerfication(String phoneNumber, boolean isResend){
        startResendTimer();
        setProgresBar(true);

        PhoneAuthOptions.Builder builder =
                PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phoneNumber).
                        setTimeout(timeOut, TimeUnit.SECONDS).setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                signIn(phoneAuthCredential);
                                setProgresBar(false);

                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {

                                AndroidUtil.showToastLong(getApplicationContext(),"Verification Failed");
                                setProgresBar(false);

                            }

                            @Override
                            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                super.onCodeSent(s, forceResendingToken);
                                verficationCode = s;
                                resendingToken = forceResendingToken;
                                AndroidUtil.showToastLong(getApplicationContext(),"Code Sent Successfully");
                                setProgresBar(false);
                            }
                        });

        if (isResend){
            PhoneAuthProvider.verifyPhoneNumber(builder.setForceResendingToken(resendingToken).build());
        }else{
            PhoneAuthProvider.verifyPhoneNumber(builder.build());

        }

    }


    private void signIn(PhoneAuthCredential phoneAuthCredential) {

        setProgresBar(true);
        auth.signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    AndroidUtil.showToastLong(getApplicationContext(),"Login Successful");
                    setProgresBar(false);
                    Intent intent = new Intent(Verfication_Activity.this, SetUserNameActivity.class);
                    intent.putExtra("phoneNumber",phoneNumber);
                    startActivity(intent);
                }else {
                    AndroidUtil.showToastLong(getApplicationContext(),"Login Failed");
                    setProgresBar(false);
                }
            }
        });

    }

    private void setProgresBar(boolean isLoading){

        if (isLoading){
            binding.progressBar.setVisibility(View.VISIBLE);
            binding.verficationBtn.setVisibility(View.GONE);
        }else {
            binding.progressBar.setVisibility(View.GONE);
            binding.verficationBtn.setVisibility(View.VISIBLE);
        }

    }

    private void startResendTimer() {
        binding.resendCode.setEnabled(false);
        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                timeOut--;
                runOnUiThread(() -> binding.resendCode.setText("Resend verification in " + timeOut + " seconds"));
                if (timeOut <= 0) {
                    timeOut = 60L;
                    timer.cancel();
                    runOnUiThread(() -> binding.resendCode.setEnabled(true));
                }
            }
        };
        timer.scheduleAtFixedRate(timerTask, 0, 1000);
    }




}
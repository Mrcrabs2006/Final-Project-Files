package com.example.smartchat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.adapter.GroupChatContactAdapter;
import com.example.smartchat.databinding.ActivityCreateGroupChatBinding;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import timber.log.Timber;

public class createGroupChat extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    ActivityCreateGroupChatBinding binding;
    GroupChatContactAdapter adapter;
    RecyclerView recyclerView;
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    private static final int CONTACT_LOADER_ID = 1;
    GroupChatModel groupChatModel;
    boolean groupChatCreated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateGroupChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        recyclerView = findViewById(R.id.usersRecycleView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        groupChatCreated = getIntent().getBooleanExtra("alreadyCreated", false);

        if (groupChatCreated) {
            binding.enterGroupName.setText("Adding Members");
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    PERMISSIONS_REQUEST_READ_CONTACTS);
        } else {
            LoaderManager.getInstance(this).initLoader(CONTACT_LOADER_ID, null, this);
        }

        // In createGroupChat.java

        binding.fabCreateGroup.setOnClickListener(btn -> {
            if (adapter != null) {
                List<String> selectedUsers = adapter.getSelectedUserIds();

                if (selectedUsers.isEmpty()) {
                    AndroidUtil.showToastShort(this, "No users selected");
                    return;
                }

                if (groupChatCreated) {
                    String groupId = getIntent().getStringExtra("groupId");
                    addMembersToGroup(groupId, selectedUsers);
                    return;
                } else {
                    selectedUsers.add(FireBaseUtil.currentUSerId());
                    String groupChatId = createGroupChatId(selectedUsers);

                    groupChatModel = new GroupChatModel();
                    groupChatModel.setChatroomName(binding.enterGroupName.getText().toString());
                    groupChatModel.setChatroomId(groupChatId);
                    groupChatModel.setAdminIds(Collections.singletonList(FireBaseUtil.currentUSerId()));
                    groupChatModel.setUserIds(selectedUsers);

                    FireBaseUtil.getGroupChatReference(groupChatId).set(groupChatModel)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    // Redirect to MainActivity after successful group creation
                                    Intent intent = new Intent(createGroupChat.this, MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    // Handle failure
                                }
                            });
                }
            } else {
                AndroidUtil.showToastShort(this, "Adapter is not initialized");
            }
        });
    }

    private void addMembersToGroup(String groupId, List<String> newMembers) {
        FireBaseUtil.getGroupChatReference(groupId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                GroupChatModel groupChatModel = task.getResult().toObject(GroupChatModel.class);
                if (groupChatModel != null) {
                    groupChatModel.getUserIds().addAll(newMembers);
                    FireBaseUtil.getGroupChatReference(groupId).set(groupChatModel)
                            .addOnCompleteListener(updateTask -> {
                                if (updateTask.isSuccessful()) {
                                    AndroidUtil.showToastShort(this, "Members added successfully");
                                } else {
                                    AndroidUtil.showToastShort(this, "Failed to add members");
                                }
                            });
                }
            }
        });
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        if (id == CONTACT_LOADER_ID) {
            return new CursorLoader(
                    this,
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null,
                    null,
                    null
            );
        }
        return null;
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        List<String> phoneNumbers = new ArrayList<>();
        if (data != null) {
            while (data.moveToNext()) {
                @SuppressLint("Range") String phoneNumber = data.getString(data.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                phoneNumber = phoneNumber.replaceAll("[\\s\\-()]", ""); // Normalize the phone number
                phoneNumbers.add(phoneNumber);
            }
            data.close();
        }

        Timber.tag("phoneNumbers").i("getPhoneNumbers: " + phoneNumbers);
        searchUsersFromContacts(phoneNumbers);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        // Do nothing
    }

    private void searchUsersFromContacts(List<String> phoneNumbers) {
        final int BATCH_SIZE = 10;
        final List<UserModel> allMatchingUsers = new ArrayList<>();
        final int[] processedBatches = {0};

        for (int i = 0; i < phoneNumbers.size(); i += BATCH_SIZE) {
            int end = Math.min(i + BATCH_SIZE, phoneNumbers.size());
            List<String> batch = phoneNumbers.subList(i, end);

            Query query = FireBaseUtil.allUsersCollectionReference()
                    .whereIn("phone", batch);

            query.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    QuerySnapshot querySnapshot = task.getResult();
                    if (querySnapshot != null && !querySnapshot.isEmpty()) {
                        allMatchingUsers.addAll(querySnapshot.toObjects(UserModel.class));
                    }
                } else {
                    AndroidUtil.showToastShort(createGroupChat.this, "Error loading data");
                }

                processedBatches[0]++;
                if (processedBatches[0] == (phoneNumbers.size() + BATCH_SIZE - 1) / BATCH_SIZE) {
                    updateUIWithResults(allMatchingUsers);
                }
            });
        }
    }

    private void updateUIWithResults(List<UserModel> users) {
        if (users.isEmpty()) {
            AndroidUtil.showToastShort(createGroupChat.this, "No matching users found in your contacts");
        } else {
            adapter = new GroupChatContactAdapter(users, getApplicationContext());
            recyclerView.setAdapter(adapter);
        }
    }

    private String createGroupChatId(List<String> userIds) {
        Collections.sort(userIds);
        return String.join("_", userIds);
    }

    private List<String> getUserIds(List<UserModel> users) {
        List<String> userIds = new ArrayList<>();
        for (UserModel user : users) {
            userIds.add(user.getUserId());
        }
        return userIds;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_REQUEST_READ_CONTACTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                LoaderManager.getInstance(this).initLoader(CONTACT_LOADER_ID, null, this);
            } else {
                AndroidUtil.showToastShort(this, "Permission denied to read your contacts");
            }
        }
    }
}
package com.example.smartchat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.smartchat.databinding.ActivityMainBinding;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.Timestamp;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.Collections;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    String userName;
    UserModel userModel;
    BottomNavigationView bottomNavigationView;
    ChatFragment chatFragment;
    GroupChatFragment groupChatFragment;
    ProfileFragment profileFragment;
    SettingsFragment settingsFragment;
    Fragment[] fragments;
    String groupChatId;
    int currentFragmentIndex = 0;
    GroupChatModel groupChatModel;

    float x1, x2, y1, y2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        loadLocale(); // Load the selected language
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        EdgeToEdge.enable(this);

        groupChatId = FireBaseUtil.currentUSerId() + "12223332222";

        AnimationUtils.controlLottieAnimation(this, binding.mainToolbar.findViewById(R.id.search_btn));


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        chatFragment = new ChatFragment();

        profileFragment = new ProfileFragment();
        groupChatFragment = new GroupChatFragment();
        settingsFragment = new SettingsFragment();
        fragments = new Fragment[]{chatFragment, groupChatFragment, profileFragment, settingsFragment};

        binding.searchBtn.setOnClickListener((v) -> {
            Intent intent = new Intent(MainActivity.this, SearchUserActivity.class);
            startActivity(intent);
        });

        binding.moreOptions.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(MainActivity.this, v);
            popupMenu.getMenuInflater().inflate(R.menu.main_activity_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {

                if (item.getItemId() == R.id.createGroupChat) {
                    Intent intent = new Intent(MainActivity.this, createGroupChat.class);
                    startActivity(intent);
                    return true;
                }
                return false;
            });

            popupMenu.show();
        });


        binding.bottomNavigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.menu_chat) {
                    currentFragmentIndex = 0;
                } else if (itemId == R.id.group_chat) {
                    currentFragmentIndex = 1;

                } else if (itemId == R.id.menu_Profile) {
                    currentFragmentIndex = 2;
                } else if (itemId == R.id.menu_settings) {
                    currentFragmentIndex = 3;
                }

                switchFragment(currentFragmentIndex, true);
                return true;
            }
        });

        // Set the default selected item
        binding.bottomNavigation.setSelectedItemId(R.id.menu_chat);
        getFCMToken();

        if (getIntent().getBooleanExtra("navigateToGroupChat", false)) {
            // Simulate a swipe to the left
            if (currentFragmentIndex < fragments.length - 1) {
                currentFragmentIndex++;
                switchFragment(currentFragmentIndex, true);
                updateBottomNavigationView(currentFragmentIndex);
            }
        }

        if (!isMobileDataEnabled() && !isWifiEnabled()) {
            // Guide the user to the settings page to enable mobile data or Wi-Fi
            Toast.makeText(this, "Please enable mobile data or Wi-Fi", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
            startActivity(intent);
        }

    }

    private boolean isWifiEnabled() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifiNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return wifiNetwork != null && wifiNetwork.isConnected();
    }



    private boolean isMobileDataEnabled() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE;
    }





    private void createGroupCall() {

        AndroidUtil.showToastShort(this, "code will be implemented later");
    }

    private void switchFragment(int index, boolean isForward) {
        Fragment selectedFragment = fragments[index];
        if (selectedFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(
                            isForward ? R.anim.fade_in : R.anim.slide_out_left,
                            isForward ? R.anim.slide_out_right : R.anim.fade_out,
                            isForward ? R.anim.fade_in : R.anim.slide_out_left,
                            isForward ? R.anim.slide_out_right : R.anim.fade_out)
                    .replace(R.id.main_frame_layout, selectedFragment)
                    .commit();
        }
    }

    private void loadLocale() {
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        String language = prefs.getString("My_Lang", "");
        setLocale(language);
    }

    private void setLocale(String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = event.getX();
                y1 = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = event.getX();
                y2 = event.getY();
                if (x1 > x2) {
                    // Swipe right to switch to the next fragment
                    if (currentFragmentIndex < fragments.length - 1) {
                        currentFragmentIndex++;
                        switchFragment(currentFragmentIndex, true);
                        updateBottomNavigationView(currentFragmentIndex);
                    }
                } else if (x1 < x2) {
                    // Swipe left to go back to the previous fragment
                    if (currentFragmentIndex > 0) {
                        currentFragmentIndex--;
                        switchFragment(currentFragmentIndex, false);
                        updateBottomNavigationView(currentFragmentIndex);
                    }
                }
                break;
        }
        return super.onTouchEvent(event);
    }

    private void updateBottomNavigationView(int index) {
        switch (index) {
            case 0:
                binding.bottomNavigation.setSelectedItemId(R.id.menu_chat);
                break;
            case 1:
                binding.bottomNavigation.setSelectedItemId(R.id.group_chat);
                break;
            case 2:
                binding.bottomNavigation.setSelectedItemId(R.id.menu_Profile);
                break;
            case 3:
                binding.bottomNavigation.setSelectedItemId(R.id.menu_settings);
                break;
        }
    }


    private void getFCMToken() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String token = task.getResult();
                FireBaseUtil.currentUserDetails().update("fcmToken", token);

            }
        });
    }


}

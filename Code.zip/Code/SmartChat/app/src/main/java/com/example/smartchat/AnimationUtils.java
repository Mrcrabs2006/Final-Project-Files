package com.example.smartchat;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;

import com.airbnb.lottie.LottieAnimationView;

public class AnimationUtils {

    public static void controlLottieAnimation(Context context, LottieAnimationView animationView) {
        // Load the current state of animationsEnabled from SharedPreferences
        SharedPreferences sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
        boolean animationsEnabled = sharedPreferences.getBoolean("animationsEnabled", true);

        if (!animationsEnabled) {
            // If animations are disabled, cancel the animation and hide the view
            animationView.cancelAnimation();
        } else {
            // If animations are enabled, play the animation and make sure the view is visible
            animationView.playAnimation();
        }
    }

    public static void saveAnimationPreference(Context context, boolean enableAnimations) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("animationsEnabled", enableAnimations);
        editor.apply();
    }
}

package com.example.smartchat;

public class AppConfig {
    // Global flag for enabling/disabling animations
    public static boolean animationsEnabled = true;
}

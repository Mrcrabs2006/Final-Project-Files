// GroupChatFragment.java
package com.example.smartchat;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.adapter.RecentGroupChatAdapter;
import com.example.smartchat.databinding.FragmentGroupChatBinding;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.Query;

public class GroupChatFragment extends Fragment {

    RecyclerView recyclerView;
    FragmentGroupChatBinding binding;
    RecentGroupChatAdapter adapter;

    public GroupChatFragment() {
        // Required empty public constructor
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = binding.RecyclerView;
        setupRecyclerView();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGroupChatBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    private void setupRecyclerView() {
        // Update the query to target group chats
        Query query = FireBaseUtil.allGroupChatCollectionReference()
                .orderBy("lastMessageTimestamp", Query.Direction.DESCENDING);

        // Update FirestoreRecyclerOptions to use GroupChatModel
        FirestoreRecyclerOptions<GroupChatModel> options = new FirestoreRecyclerOptions.Builder<GroupChatModel>()
                .setQuery(query, GroupChatModel.class)
                .build();

        // Ensure the adapter is for group chats
        adapter = new RecentGroupChatAdapter(options, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (adapter != null) {
            adapter.startListening();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.startListening();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (adapter != null) {
            adapter.stopListening();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (adapter != null) {
            adapter.stopListening();
        }
    }
}
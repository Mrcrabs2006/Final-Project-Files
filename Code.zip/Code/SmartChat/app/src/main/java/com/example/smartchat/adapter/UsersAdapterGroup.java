package com.example.smartchat.adapter;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.Chat_Activity;
import com.example.smartchat.GroupChatTexting;
import com.example.smartchat.MainActivity;
import com.example.smartchat.R;
import com.example.smartchat.model.GroupChatModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class UsersAdapterGroup extends FirestoreRecyclerAdapter<UserModel, UsersAdapterGroup.UserModel> {

    private final String groubId;
    Context context;
    GroupChatModel groupChatModel;

    public UsersAdapterGroup(@NonNull FirestoreRecyclerOptions<com.example.smartchat.model.UserModel> options, Context context, String groupId) {
        super(options);
        this.context = context;
        this.groubId = groupId;
    }

    @Override
    protected void onBindViewHolder(@NonNull UserModel holder, int position, @NonNull com.example.smartchat.model.UserModel model) {
        // animations
        holder.profilePic.setAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_transition_animation));
        holder.container.setAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_scale_animation));

        holder.userNameText.setText(model.getUsername());
        holder.phoneNumber.setText(model.getPhone());
        if (model.getUserId().equals(FireBaseUtil.currentUSerId())) {
            holder.userNameText.setText(String.format("%s", model.getUsername() + "(You)"));
        }

        FireBaseUtil.getOtherProfilePicStorageRef(model.getUserId()).getDownloadUrl()
                .addOnCompleteListener(task1 -> {
                    if (task1.isSuccessful() && task1.getResult() != null) {
                        Uri uri = task1.getResult();
                        AndroidUtil.setProfilePic(context, uri, holder.profilePic);
                    } else {
                        holder.profilePic.setImageResource(R.drawable.chat_round);
                    }
                });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, Chat_Activity.class);
            AndroidUtil.passUserModelAsIntent(intent, model);
            intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });

        FireBaseUtil.isCurrentUserAdmin(groubId).addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                boolean isAdmin = task.getResult();
                if (isAdmin) {
                    holder.removeUser.setVisibility(View.VISIBLE);
                } else {
                    holder.removeUser.setVisibility(View.GONE);
                }
            } else {
                holder.removeUser.setVisibility(View.GONE);
            }
        });

        holder.removeUser.setOnClickListener(v -> {
            FireBaseUtil.getGroupChatReference(groubId).get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    groupChatModel = task.getResult().toObject(GroupChatModel.class);
                    if (groupChatModel != null) {
                        groupChatModel.getUserIds().remove(model.getUserId());
                        FireBaseUtil.getGroupChatReference(groubId).set(groupChatModel);
                        removeUserFromRecyclerView(holder.getBindingAdapterPosition());

                    }
                }
            });
        });
    }

    private void removeUserFromRecyclerView(int position) {
        notifyItemRemoved(position);
    }

    @NonNull
    @Override
    public UserModel onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.group_users_list, parent, false);
        return new UserModel(view);
    }

    static class UserModel extends RecyclerView.ViewHolder {
        TextView userNameText;
        TextView phoneNumber;
        ImageView profilePic;
        RelativeLayout container;
        Button removeUser;

        public UserModel(@NonNull View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.action_container);
            userNameText = itemView.findViewById(R.id.userName_txt);
            phoneNumber = itemView.findViewById(R.id.txt_phoneNumber);
            profilePic = itemView.findViewById(R.id.img_user);
            removeUser = itemView.findViewById(R.id.btn_remove); // Corrected initialization
        }
    }
}
package com.example.smartchat.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.telephony.AccessNetworkConstants;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartchat.Chat_Activity;
import com.example.smartchat.R;
import com.example.smartchat.model.ChatRoomModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.EncryptionUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.Timestamp;

import java.util.Objects;

public class RecentChatAdapter extends FirestoreRecyclerAdapter<ChatRoomModel, RecentChatAdapter.ChatRoomModelViewHolder> {

    Context context;
    UserModel otherUser;
    ChatRoomModel chatRoomModel;
    final int MAX_MESSAGE_LENGTH = 50;

    public RecentChatAdapter(@NonNull FirestoreRecyclerOptions<ChatRoomModel> options, Context context, UserModel otherUser, ChatRoomModel chatRoomModel) {
        super(options);
        this.context = context;
        this.otherUser = otherUser;
        this.chatRoomModel = chatRoomModel;
    }


    @NonNull
    @Override
    public ChatRoomModelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_container_user_recent, parent, false);

        return new ChatRoomModelViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onBindViewHolder(@NonNull ChatRoomModelViewHolder holder, int position, @NonNull ChatRoomModel model) {

        FireBaseUtil.getOtherUserFromChatroom(model.getUserIds())
                .get().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        UserModel otherUserModel = task.getResult().toObject(UserModel.class);

                        if (otherUser != null) {
                            assert otherUserModel != null;


                                holder.userName.setText(otherUserModel.getUsername());

                            String lastMessageSenderId = model.getLastMessageSenderId();
                            String lastMessage = model.getLastMessage();
                            Timestamp lastMessageTimestamp = model.getLastMessageTimestamp();



                            if (!lastMessageSenderId.isEmpty() && !lastMessage.isEmpty()) {
                                boolean lastMessageSentByMe = lastMessageSenderId.equals(FireBaseUtil.currentUSerId());

                                try {

                                    String decryptedMessage = lastMessageSentByMe ? EncryptionUtil.decrypt(lastMessage, otherUserModel.getUserId()) :
                                            EncryptionUtil.decrypt(lastMessage, FireBaseUtil.currentUSerId());

                                    String truncatedMessage = truncateMessage(decryptedMessage, MAX_MESSAGE_LENGTH);

                                    holder.lastMessage.setText(truncatedMessage);


                                } catch (Exception e) {
                                    holder.lastMessage.setText(truncateMessage(lastMessage, MAX_MESSAGE_LENGTH));
                                }
                            } else {
                                holder.lastMessage.setText("No messages yet");
                            }

                            holder.timeStamp.setText(FireBaseUtil.timestampToString(lastMessageTimestamp));


                        }


                        if (!Objects.equals(model.getChatroomId(), FireBaseUtil.currentUSerId() + "_" + FireBaseUtil.currentUSerId())) {
                            FireBaseUtil.getOtherProfilePicStorageRef(otherUserModel.getUserId()).getDownloadUrl()
                                    .addOnCompleteListener(task1 -> {
                                        if (task1.isSuccessful() && task1.getResult() != null) {
                                            Uri uri = task1.getResult();
                                            AndroidUtil.setProfilePic(context, uri, holder.profilePic);
                                        } else {
                                            holder.profilePic.setImageResource(R.drawable.profile_round_black);
                                        }
                                    });
                        } else {
                            FireBaseUtil.getCurrentProfilePicStorageRef().getDownloadUrl()
                                    .addOnCompleteListener(task2 -> {
                                        if (task.isSuccessful() && task2.getResult() != null) {
                                            Uri uri = task2.getResult();
                                            AndroidUtil.setProfilePic(context, uri, holder.profilePic);
                                        }
                                    });
                        }


                        holder.itemView.setOnClickListener(v -> {
                            //navigate to chat activity
                            Intent intent = new Intent(context, Chat_Activity.class);
                            AndroidUtil.passUserModelAsIntent(intent, otherUserModel);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                        });

                    }
                });

    }

    private String truncateMessage(String message, int maxLength) {
        if (message.length() <= maxLength) {
            return message;
        }
        return message.substring(0, maxLength - 3) + "...";
    }


    static class ChatRoomModelViewHolder extends RecyclerView.ViewHolder {

        TextView userName;
        TextView lastMessage;
        TextView timeStamp;
        ImageView profilePic;

        public ChatRoomModelViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.userName_txt);
            profilePic = itemView.findViewById(R.id.img_user);

            lastMessage = itemView.findViewById(R.id.lastMessage_txt);
            timeStamp = itemView.findViewById(R.id.timeStamp_txt);
        }
    }
}

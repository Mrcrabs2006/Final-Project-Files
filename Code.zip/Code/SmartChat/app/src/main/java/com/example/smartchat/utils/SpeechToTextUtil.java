// File: app/src/main/java/com/example/smartchat/utils/SpeechToTextUtil.java
package com.example.smartchat.utils;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Locale;

public class SpeechToTextUtil {
    public static final int RESULT_SPEECH = 4;

    public static void startSpeechToText(Activity activity) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        try {
            activity.startActivityForResult(intent, RESULT_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(activity.getApplicationContext(), "Your device doesn't support Speech to Text", Toast.LENGTH_SHORT).show();
        }
    }

    public static void handleSpeechResult(int requestCode, int resultCode, @Nullable Intent data, EditText editText) {
        if (requestCode == RESULT_SPEECH && resultCode == Activity.RESULT_OK && data != null) {
            ArrayList<String> text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (text != null && !text.isEmpty()) {
                editText.setText(text.get(0));
            }
        }
    }
}
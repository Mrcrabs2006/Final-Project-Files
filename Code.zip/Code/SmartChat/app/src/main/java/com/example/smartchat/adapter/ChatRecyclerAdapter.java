package com.example.smartchat.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.smartchat.R;
import com.example.smartchat.TranslationCallback;
import com.example.smartchat.model.ChatMessageModel;
import com.example.smartchat.model.ChatRoomModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.EncryptionUtil;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ChatRecyclerAdapter extends FirestoreRecyclerAdapter<ChatMessageModel, RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_TEXT = 1;
    private static final int VIEW_TYPE_IMAGE = 2;
    private static final int VIEW_TYPE_DOCUMENT = 3;
    private static final int VIEW_TYPE_CONTACT = 4;

    private static final String TAG = "ChatRecyclerAdapter";

    private Context context;
    private UserModel otherUser;
    private String selectedLanguage;
    private boolean translationEnabled;
    private Set<String> blockedUsersDisplayed;
    private Translator translator;
    private ChatRoomModel chatRoomModel;

    public ChatRecyclerAdapter(@NonNull FirestoreRecyclerOptions<ChatMessageModel> options, Context context, UserModel otherUser, String selectedLanguage, boolean translationEnabled, ChatRoomModel chatRoomModel) {
        super(options);
        this.context = context;
        this.otherUser = otherUser;
        this.selectedLanguage = selectedLanguage;
        this.translationEnabled = translationEnabled;
        this.blockedUsersDisplayed = new HashSet<>();
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessageModel model = getItem(position);
        String messageType = model.getMessageType();

        if (messageType == null) {
            return VIEW_TYPE_TEXT;
        }

        switch (messageType) {
            case "image":
                return VIEW_TYPE_IMAGE;
            case "document":
                return VIEW_TYPE_DOCUMENT;
            case "contact":
                return VIEW_TYPE_CONTACT;
            default:
                return VIEW_TYPE_TEXT;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_IMAGE) {
            View view = LayoutInflater.from(context).inflate(R.layout.chat_image_message_row, parent, false);
            return new ImageMessageViewHolder(view);
        } else if (viewType == VIEW_TYPE_DOCUMENT) {
            View view = LayoutInflater.from(context).inflate(R.layout.chat_document_message_row, parent, false);
            return new DocumentMessageViewHolder(view);
        } else if (viewType == VIEW_TYPE_CONTACT) {
            View view = LayoutInflater.from(context).inflate(R.layout.contact_message_row, parent, false);
            return new ContactMessageViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.chat_message_recycler_row, parent, false);
            return new TextMessageViewHolder(view);
        }
    }


    @Override
    protected void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, @NonNull ChatMessageModel model) {
        String currentUserId = FireBaseUtil.currentUSerId();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(currentUserId);

        userRef.get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot.exists()) {
                List<String> blockedUsers = (List<String>) documentSnapshot.get("blockedUsers");

                if (blockedUsers != null && blockedUsers.contains(model.getSenderId())) {
                    handleBlockedMessage(holder, model);
                } else {
                    switch (getItemViewType(position)) {
                        case VIEW_TYPE_IMAGE:
                            bindImageMessage((ImageMessageViewHolder) holder, model, currentUserId);
                            break;
                        case VIEW_TYPE_DOCUMENT:
                            bindDocumentMessage((DocumentMessageViewHolder) holder, model, currentUserId);
                            break;
                        case VIEW_TYPE_CONTACT:
                            bindContactMessage((ContactMessageViewHolder) holder, model, currentUserId);
                            break;
                        default:
                            bindTextMessage((TextMessageViewHolder) holder, model, currentUserId);
                            break;
                    }
                }
            }
        }).addOnFailureListener(e -> Log.e(TAG, "Error fetching blocked users", e));
    }


    private void bindDocumentMessage(DocumentMessageViewHolder holder, ChatMessageModel model, String currentUserId) {

        if (model.getSenderId().equals(currentUserId)) {
            holder.leftDocumentLayout.setVisibility(View.GONE);
            holder.rightDocumentLayout.setVisibility(View.VISIBLE);
            Log.i("TAG", "bindDocumentMessage: " + model.getFileName());
            holder.rightDocumentTextView.setText(model.getFileName());
        } else {
            holder.rightDocumentLayout.setVisibility(View.GONE);
            holder.leftDocumentLayout.setVisibility(View.VISIBLE);
            holder.leftDocumentTextView.setText(model.getFileName());
        }

        View.OnClickListener documentClickListener = v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(model.getMessage()), "*/*");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Add this line
            context.startActivity(intent);
        };

        holder.leftDocumentTextView.setOnClickListener(documentClickListener);
        holder.rightDocumentTextView.setOnClickListener(documentClickListener);
    }

    private void handleBlockedMessage(RecyclerView.ViewHolder holder, ChatMessageModel model) {
        if (!blockedUsersDisplayed.contains(model.getSenderId())) {
            if (holder instanceof TextMessageViewHolder) {
                TextMessageViewHolder textHolder = (TextMessageViewHolder) holder;
                textHolder.leftChatLayout.setVisibility(View.GONE);
                textHolder.rightChatLayout.setVisibility(View.GONE);
                textHolder.blockedMessageTextView.setVisibility(View.VISIBLE);
                textHolder.blockedMessageTextView.setText("This user is blocked.");
            } else if (holder instanceof ImageMessageViewHolder) {
                ImageMessageViewHolder imageHolder = (ImageMessageViewHolder) holder;
                imageHolder.leftImageLayout.setVisibility(View.GONE);
                imageHolder.rightImageLayout.setVisibility(View.GONE);
                imageHolder.blockedMessageTextView.setVisibility(View.VISIBLE);
                imageHolder.blockedMessageTextView.setText("This user is blocked.");
            }
            blockedUsersDisplayed.add(model.getSenderId());
        } else {
            hideAllViews(holder);
        }
    }

    private void hideAllViews(RecyclerView.ViewHolder holder) {
        if (holder instanceof TextMessageViewHolder) {
            TextMessageViewHolder textHolder = (TextMessageViewHolder) holder;
            textHolder.leftChatLayout.setVisibility(View.GONE);
            textHolder.rightChatLayout.setVisibility(View.GONE);
            textHolder.blockedMessageTextView.setVisibility(View.GONE);
        } else if (holder instanceof ImageMessageViewHolder) {
            ImageMessageViewHolder imageHolder = (ImageMessageViewHolder) holder;
            imageHolder.leftImageLayout.setVisibility(View.GONE);
            imageHolder.rightImageLayout.setVisibility(View.GONE);
            imageHolder.blockedMessageTextView.setVisibility(View.GONE);
        }
    }

    private void bindTextMessage(TextMessageViewHolder holder, ChatMessageModel model, String currentUserId) {
        holder.blockedMessageTextView.setVisibility(View.GONE);

        if (model.getSenderId().equals(currentUserId)) {
            holder.leftChatLayout.setVisibility(View.GONE);
            holder.rightChatLayout.setVisibility(View.VISIBLE);
            try {
                holder.rightChatTextview.setText(EncryptionUtil.decrypt(model.getMessage(), otherUser.getUserId()));
            } catch (Exception e) {
                holder.rightChatTextview.setText("Error decrypting message");
                Log.e(TAG, "Error decrypting message", e);
            }
        } else {
            holder.rightChatLayout.setVisibility(View.GONE);
            holder.leftChatLayout.setVisibility(View.VISIBLE);
            try {
                String originalMessage = EncryptionUtil.decrypt(model.getMessage(), FireBaseUtil.currentUSerId());
                holder.leftChatTextview.setText(originalMessage);

                if (translationEnabled && !selectedLanguage.equals("en")) {
                    handleTranslation(holder.leftChatTextview, originalMessage);
                }
            } catch (Exception e) {
                holder.leftChatTextview.setText("Error decrypting message");
                Log.e(TAG, "Error decrypting message", e);
            }
        }

        holder.leftChatTextview.setOnClickListener(v -> {
            if (this.imageClickListener != null) {
                this.imageClickListener.onImageClick(model.getMessage());
            }
        });


    }


    private void bindImageMessage(ImageMessageViewHolder holder, ChatMessageModel model, String currentUserId) {
        holder.blockedMessageTextView.setVisibility(View.GONE);

        if (model.getSenderId().equals(currentUserId)) {
            holder.leftImageLayout.setVisibility(View.GONE);
            holder.rightImageLayout.setVisibility(View.VISIBLE);
            Glide.with(context).load(model.getMessage()).into(holder.rightImageView);
        } else {
            holder.rightImageLayout.setVisibility(View.GONE);
            holder.leftImageLayout.setVisibility(View.VISIBLE);
            Glide.with(context).load(model.getMessage()).into(holder.leftImageView);
        }

        View.OnClickListener imageClickListener = v -> {
            if (this.imageClickListener != null) {
                this.imageClickListener.onImageClick(model.getMessage());
            }
        };

        holder.leftImageView.setOnClickListener(imageClickListener);
        holder.rightImageView.setOnClickListener(imageClickListener);
    }

    private void handleTranslation(TextView textView, String originalMessage) {
        detectLanguage(originalMessage, new TranslationCallback() {
            @Override
            public void onTranslationSuccess(String languageCode) {
                if (!languageCode.equals(selectedLanguage)) {
                    translateText(originalMessage, languageCode, selectedLanguage, new TranslationCallback() {
                        @Override
                        public void onTranslationSuccess(String translatedText) {
                            Log.i(TAG, "Translated text: " + translatedText);
                            textView.setText(translatedText);
                        }

                        @Override
                        public void onTranslationError(String error) {
                            Log.e(TAG, error);
                            // Keep the original text if translation fails
                        }
                    });
                }
            }

            @Override
            public void onTranslationError(String error) {
                Log.e(TAG, error);
                // Keep the original text if language detection fails
            }
        });
    }

    private void detectLanguage(String text, TranslationCallback callback) {
        LanguageIdentifier languageIdentifier = LanguageIdentification.getClient(
                new LanguageIdentificationOptions.Builder()
                        .setConfidenceThreshold(0.34f)
                        .build());

        languageIdentifier.identifyLanguage(text)
                .addOnSuccessListener(languageCode -> {
                    Log.i(TAG, "Detected language: " + languageCode);
                    if (languageCode.equals("und") || languageCode.isEmpty()) {
                        callback.onTranslationSuccess("en");
                    } else {
                        callback.onTranslationSuccess(languageCode);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Language detection failed", e);
                    callback.onTranslationSuccess("en");
                });
    }

    private void translateText(String text, String sourceLanguageCode, String targetLanguageCode, TranslationCallback callback) {
        if (sourceLanguageCode == null || targetLanguageCode == null) {
            callback.onTranslationError("Invalid language code");
            return;
        }
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguageCode)
                .setTargetLanguage(targetLanguageCode)
                .build();
        translator = Translation.getClient(options);

        DownloadConditions conditions = new DownloadConditions.Builder()
                .requireWifi()
                .build();

        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(aVoid -> {
                    Log.i(TAG, "Translation model downloaded successfully");
                    translator.translate(text)
                            .addOnSuccessListener(translatedText -> {
                                Log.i(TAG, "Translated text: " + translatedText);
                                callback.onTranslationSuccess(translatedText);
                            })
                            .addOnFailureListener(e -> {
                                Log.e(TAG, "Translation failed", e);
                                callback.onTranslationError("Translation failed.");
                            });
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Model download failed", e);
                    callback.onTranslationError("Model download failed.");
                });
    }

    public void setTranslationEnabled(boolean enabled) {
        this.translationEnabled = enabled;
        notifyDataSetChanged();
    }

    public void setSelectedLanguage(String language) {
        this.selectedLanguage = language;
        notifyDataSetChanged();
    }

    static class TextMessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout leftChatLayout, rightChatLayout;
        TextView leftChatTextview, rightChatTextview, blockedMessageTextView;

        public TextMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftChatLayout = itemView.findViewById(R.id.left_chat_layout);
            rightChatLayout = itemView.findViewById(R.id.right_chat_layout);
            leftChatTextview = itemView.findViewById(R.id.left_chat_textview);
            rightChatTextview = itemView.findViewById(R.id.right_chat_textview);
            blockedMessageTextView = itemView.findViewById(R.id.blocked_message_textview);
        }
    }


    static class ImageMessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout leftImageLayout, rightImageLayout;
        ImageView leftImageView, rightImageView;
        TextView blockedMessageTextView;

        public ImageMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftImageLayout = itemView.findViewById(R.id.left_image_layout);
            rightImageLayout = itemView.findViewById(R.id.right_image_layout);
            leftImageView = itemView.findViewById(R.id.left_image_view);
            rightImageView = itemView.findViewById(R.id.right_image_view);
            blockedMessageTextView = itemView.findViewById(R.id.blocked_message_textview);
        }
    }

    private OnImageClickListener imageClickListener;

    public interface OnImageClickListener {
        void onImageClick(String imageUrl);
    }

    public void setOnImageClickListener(OnImageClickListener listener) {
        this.imageClickListener = listener;
    }

    static class DocumentMessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout leftDocumentLayout, rightDocumentLayout;
        TextView leftDocumentTextView, rightDocumentTextView;

        public DocumentMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftDocumentLayout = itemView.findViewById(R.id.left_document_layout);
            rightDocumentLayout = itemView.findViewById(R.id.right_document_layout);
            leftDocumentTextView = itemView.findViewById(R.id.left_document_textview);
            rightDocumentTextView = itemView.findViewById(R.id.right_document_textview);
        }
    }

    private void bindContactMessage(ContactMessageViewHolder holder, ChatMessageModel model, String currentUserId) {
        if (model.getSenderId().equals(currentUserId)) {
            holder.leftContactLayout.setVisibility(View.GONE);
            holder.rightContactLayout.setVisibility(View.VISIBLE);
            holder.rightContactName.setText(model.getContactName());
            holder.rightContactPhone.setText(model.getContactPhone());
            holder.rightContactTime.setText(FireBaseUtil.timestampToString(model.getTimestamp()));
        } else {
            holder.rightContactLayout.setVisibility(View.GONE);
            holder.leftContactLayout.setVisibility(View.VISIBLE);
            holder.leftContactName.setText(model.getContactName());
            holder.leftContactPhone.setText(model.getContactPhone());
            holder.leftContactTime.setText(FireBaseUtil.timestampToString(model.getTimestamp()));
        }

        View.OnClickListener contactClickListener = v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + model.getContactPhone()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Add this line
            context.startActivity(intent);
        };

        holder.leftContactLayout.setOnClickListener(contactClickListener);
        holder.rightContactLayout.setOnClickListener(contactClickListener);
    }

    static class ContactMessageViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout leftContactLayout, rightContactLayout;
        TextView leftContactName, rightContactName, leftContactPhone, rightContactPhone,leftContactTime,rightContactTime;

        public ContactMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            leftContactLayout = itemView.findViewById(R.id.left_contact_layout);
            rightContactLayout = itemView.findViewById(R.id.right_contact_layout);
            leftContactName = itemView.findViewById(R.id.left_contact_name);
            rightContactName = itemView.findViewById(R.id.right_contact_name);
            leftContactPhone = itemView.findViewById(R.id.contact_number_left);
            rightContactPhone = itemView.findViewById(R.id.contact_number_right);
            leftContactTime = itemView.findViewById(R.id.contact_time_left);
            rightContactTime = itemView.findViewById(R.id.contact_time_right);
        }
    }
}
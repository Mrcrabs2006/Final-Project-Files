package com.example.smartchat;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartchat.databinding.FragmentProfileBinding;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.AndroidUtil;
import com.example.smartchat.utils.EditFieldDialog;
import com.example.smartchat.utils.FireBaseUtil;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.firebase.messaging.FirebaseMessaging;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class ProfileFragment extends Fragment {
    FragmentProfileBinding binding;
    UserModel currnUserModel;
    Uri selectedImageUri;
    ActivityResultLauncher<Intent> imagePickLauncher;

    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imagePickLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) {
                Intent data = result.getData();
                if (data != null && data.getData() != null) {
                    selectedImageUri = data.getData();
                    AndroidUtil.setProfilePic(getContext(), selectedImageUri, binding.profileImageView);
                } else {
                    binding.profileImageView.setImageResource(R.drawable.chat_round);
                }
            }
        });
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);

        getUserData();

        binding.profleUpdateBtn.setOnClickListener(v -> updateBtnClick());

        binding.profileImageView.setOnClickListener(v -> {
            ImagePicker.with(this).cropSquare().compress(512).maxResultSize(512, 512).createIntent(intent -> {
                imagePickLauncher.launch(intent);
                return null;
            });
        });

        binding.cardViewUserName.setOnClickListener(v -> showEditFieldDialog(binding.profileUsername.getText().toString(), newText -> binding.profileUsername.setText(newText)));
        binding.cardViewStatus.setOnClickListener(v -> showEditFieldDialog(binding.profileStatus.getText().toString(), newText -> binding.profileStatus.setText(newText)));

        // Remove the edit dialog for phone number
        // binding.cardViewPhone.setOnClickListener(v -> showEditFieldDialog(binding.phoneNumber.getText().toString(), newText -> binding.phoneNumber.setText(newText)));

        // Add a new OnClickListener to copy the phone number to the clipboard
        binding.cardViewPhone.setOnLongClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Phone Number", binding.phoneNumber.getText().toString());
            clipboard.setPrimaryClip(clip);
            AndroidUtil.showToastShort(getContext(), "Phone number copied to clipboard");
            return false;
        });

        return binding.getRoot();
    }

    private void showEditFieldDialog(String initialText, EditFieldDialog.OnFieldEditedListener listener) {
        EditFieldDialog editFieldDialog = new EditFieldDialog(initialText, listener);
        editFieldDialog.show(getChildFragmentManager(), "EditFieldDialog");
    }

    private void updateBtnClick() {
        String newUsername = binding.profileUsername.getText().toString();
        String newStatus = binding.profileStatus.getText().toString();
        String newPhone = binding.phoneNumber.getText().toString();

        if (newUsername.isEmpty() || newUsername.length() < 3) {
            binding.profileUsername.setError("Username length should be at least 3 chars");
            return;
        }

        currnUserModel.setUsername(newUsername);
        currnUserModel.setStatus(newStatus);
        currnUserModel.setPhone(newPhone);
        setInProgress(true);

        if (selectedImageUri != null) {
            FireBaseUtil.getCurrentProfilePicStorageRef().putFile(selectedImageUri)
                    .addOnCompleteListener(task -> updateToFirestore());
        } else {
            updateToFirestore();
        }
    }

    private void getUserData() {
        FireBaseUtil.currentUserDetails().get().addOnCompleteListener(task -> {
            currnUserModel = task.getResult().toObject(UserModel.class);

            FireBaseUtil.getCurrentProfilePicStorageRef().getDownloadUrl()
                    .addOnCompleteListener(task1 -> {
                        if (task1.isSuccessful() && task1.getResult() != null) {
                            Uri uri = task1.getResult();
                            if (isAdded()) {
                                AndroidUtil.setProfilePic(getContext(), uri, binding.profileImageView);
                            }
                        } else {
                            if (isAdded()) {
                                binding.profileImageView.setImageResource(R.drawable.chat_round);
                            }
                        }
                    });

            if (task.isSuccessful()) {
                setInProgress(false);
                binding.profileUsername.setText(task.getResult().getString("username"));
                binding.phoneNumber.setText(task.getResult().getString("phone"));
                binding.profileStatus.setText(task.getResult().getString("status"));
            }
        });
    }

    private void setInProgress(boolean inProgress) {
        if (inProgress) {
            binding.profileProgressBar.setVisibility(View.VISIBLE);
            binding.profleUpdateBtn.setVisibility(View.GONE);
        } else {
            binding.profileProgressBar.setVisibility(View.GONE);
            binding.profleUpdateBtn.setVisibility(View.VISIBLE);
        }
    }

    private void updateToFirestore() {
        FireBaseUtil.currentUserDetails().set(currnUserModel).addOnCompleteListener(task -> {
            setInProgress(false);
            if (task.isSuccessful()) {
                AndroidUtil.showToastShort(getContext(), "Updated successfully");
            } else {
                AndroidUtil.showToastShort(getContext(), "Update failed");
            }
        });
    }



}
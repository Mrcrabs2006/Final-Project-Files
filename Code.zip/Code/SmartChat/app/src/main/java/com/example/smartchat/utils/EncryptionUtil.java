package com.example.smartchat.utils;

import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionUtil {

    private static final String TAG = "EncryptionUtil";
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5PADDING";
    private static final int KEY_SIZE = 256;
    private static final int ITERATION_COUNT = 5000;
    private static final String SALT = "your_salt_value"; // Ideally, this should be a unique value for each user

    public static String encrypt(String data, String key) throws Exception {
        SecretKeySpec secretKey = generateKey(key);
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        byte[] iv = generateIV();
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        byte[] encryptedData = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        byte[] combinedData = combineIVAndEncryptedData(iv, encryptedData);
        return Base64.encodeToString(combinedData, Base64.DEFAULT);
    }

    public static String decrypt(String encryptedData, String key) throws Exception {
        SecretKeySpec secretKey = generateKey(key);
        byte[] combinedData = Base64.decode(encryptedData, Base64.DEFAULT);
        byte[] iv = extractIV(combinedData);
        byte[] encryptedBytes = extractEncryptedData(combinedData);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
        byte[] decryptedData = cipher.doFinal(encryptedBytes);
        String decodedData = new String(decryptedData, StandardCharsets.UTF_8);
        return decodedData;
    }

    private static SecretKeySpec generateKey(String key) throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] saltBytes = SALT.getBytes(StandardCharsets.UTF_8);
        PBEKeySpec spec = new PBEKeySpec(key.toCharArray(), saltBytes, ITERATION_COUNT, KEY_SIZE);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] keyBytes = factory.generateSecret(spec).getEncoded();
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }

    private static byte[] generateIV() {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    private static byte[] combineIVAndEncryptedData(byte[] iv, byte[] encryptedData) {
        byte[] combinedData = new byte[iv.length + encryptedData.length];
        System.arraycopy(iv, 0, combinedData, 0, iv.length);
        System.arraycopy(encryptedData, 0, combinedData, iv.length, encryptedData.length);
        return combinedData;
    }

    private static byte[] extractIV(byte[] combinedData) {
        byte[] iv = new byte[16];
        System.arraycopy(combinedData, 0, iv, 0, iv.length);
        return iv;
    }

    private static byte[] extractEncryptedData(byte[] combinedData) {
        byte[] encryptedData = new byte[combinedData.length - 16];
        System.arraycopy(combinedData, 16, encryptedData, 0, encryptedData.length);
        return encryptedData;
    }
}

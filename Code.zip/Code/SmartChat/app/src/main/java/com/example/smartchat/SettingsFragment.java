// SettingsFragment.java
package com.example.smartchat;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.smartchat.databinding.FragmentSettingsBinding;
import com.example.smartchat.utils.FireBaseUtil;
import com.google.firebase.messaging.FirebaseMessaging;

public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;

    public SettingsFragment() {
        // empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);

        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
        boolean animationsEnabled = sharedPreferences.getBoolean("animationsEnabled", true);

        binding.switchCancelAnimations.setChecked(!animationsEnabled);

        binding.switchCancelAnimations.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AnimationUtils.saveAnimationPreference(requireContext(), !isChecked);
            restartApp();
        });

        binding.languageCard.setOnClickListener((v) -> {
            Intent intent = new Intent(getActivity(), LanguageSelectionActivity.class);
            startActivity(intent);
        });

        binding.cardLogout.setOnClickListener((v) -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        FirebaseMessaging.getInstance().deleteToken().addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                FireBaseUtil.logout();
                                Intent intent = new Intent(getContext(), SplashActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        });
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        return binding.getRoot();
    }

    private void restartApp() {
        Intent intent = new Intent(requireContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
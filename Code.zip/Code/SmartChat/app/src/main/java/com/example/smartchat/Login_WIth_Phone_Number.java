package com.example.smartchat;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.smartchat.databinding.ActivityLoginWithPhoneNumberBinding;

public class Login_WIth_Phone_Number extends AppCompatActivity {

    ActivityLoginWithPhoneNumberBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginWithPhoneNumberBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        binding.loginCountryCode.registerCarrierNumberEditText(binding.loginPhoneNumberEdittxt);

        binding.sendverfBtn.setOnClickListener((v) ->{

            if (!binding.loginCountryCode.isValidFullNumber()){
                binding.loginPhoneNumberEdittxt.setError("Phone Number Not Valid");
                return;
            }

            Intent intent = new Intent(Login_WIth_Phone_Number.this,Verfication_Activity.class);
            intent.putExtra("phoneNumber",binding.loginCountryCode.getFullNumberWithPlus());
            startActivity(intent);

        });


        }
    }
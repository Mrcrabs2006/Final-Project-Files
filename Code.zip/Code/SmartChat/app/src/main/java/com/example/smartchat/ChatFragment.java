package com.example.smartchat;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.smartchat.adapter.RecentChatAdapter;
import com.example.smartchat.adapter.SearchUserRecyclerAdapter;
import com.example.smartchat.databinding.FragmentChatBinding;
import com.example.smartchat.model.ChatRoomModel;
import com.example.smartchat.model.UserModel;
import com.example.smartchat.utils.FireBaseUtil;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.Query;

import java.util.List;


public class ChatFragment extends Fragment {

    RecyclerView recyclerView;
    FragmentChatBinding binding;
    RecentChatAdapter adapter;




    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentChatBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = binding.RecyclerView;
        setupRecyclerView();
    }

    private void setupRecyclerView() {
        Query query = FireBaseUtil.allChatRoomCollectionReference()
                .whereArrayContains("userIds", FireBaseUtil.currentUSerId())
                .orderBy("lastMessageTimestamp", Query.Direction.DESCENDING);

        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                List<DocumentSnapshot> documents = task.getResult().getDocuments();
                for (DocumentSnapshot document : documents) {
                    Log.d("ChatFragment", document.getId() + " => " + document.getData());
                }
            } else {
                Log.d("ChatFragment", "Error getting documents: ", task.getException());
            }
        });





        FirestoreRecyclerOptions<ChatRoomModel> options = new FirestoreRecyclerOptions.Builder<ChatRoomModel>()
                .setQuery(query, ChatRoomModel.class)
                .build();

        adapter = new RecentChatAdapter(options, getContext(), new UserModel(), new ChatRoomModel());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }


    @Override
    public void onStart() {
        super.onStart();
        if (adapter != null) {
            adapter.startListening();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        if (adapter!=null){
            adapter.notifyDataSetChanged();

        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (adapter!=null){
            adapter.startListening();

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(adapter!=null){
            adapter.stopListening();
        }
    }
}
pluginManagement {
    repositories {
        maven(url = "https://jitpack.io")
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()


    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven(url = "https://jitpack.io")
        google()
        mavenCentral()

        // Zego Maven Repository
        maven {
            url = uri("https://storage.zego.im/maven")
        }



        // JitPack Maven Repository (already declared above, so you can remove this if it's redundant)
        maven {
            url = uri("https://www.jitpack.io")
        }
    }
}


rootProject.name = "Smart Chat"
include(":app")
